/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/approveChangeOrder.ts" enhancement="_blank"/>
export const qryLocateChangeOrderRoute = 'buildFlowFsm.approveChangeOrder.qryLocateChangeOrder';
export const cmdApproveChangeOrderDecisionRoute = 'buildFlowFsm.approveChangeOrder.cmdApproveChangeOrderDecision';
export const cmdHandoffApprovedChangeOrderToBillingRoute = 'buildFlowFsm.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling';
export const qryClientPickerRoute = 'buildFlowFsm.approveChangeOrder.qryClientPicker';
