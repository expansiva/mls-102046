/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/assignWorkTask.ts" enhancement="_blank"/>
export const qryLocateProjectRoute = 'buildFlowFsm.assignWorkTask.qryLocateProject';
export const qryInspectProjectTimelineRoute = 'buildFlowFsm.assignWorkTask.qryInspectProjectTimeline';
export const qryLocateFieldWorkerRoute = 'buildFlowFsm.assignWorkTask.qryLocateFieldWorker';
export const cmdCreateWorkTaskRoute = 'buildFlowFsm.assignWorkTask.cmdCreateWorkTask';
export const cmdHandoffWorkTaskToFieldWorkerRoute = 'buildFlowFsm.assignWorkTask.cmdHandoffWorkTaskToFieldWorker';
