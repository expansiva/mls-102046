/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/changeOrderDecisionCatalogue.ts" enhancement="_blank"/>
export const qryListChangeOrderDecisionRoute = 'buildFlowFsm.changeOrderDecisionCatalogue.qryListChangeOrderDecision';
export const cmdCreateChangeOrderDecisionRoute = 'buildFlowFsm.changeOrderDecisionCatalogue.cmdCreateChangeOrderDecision';
export const cmdUpdateChangeOrderDecisionRoute = 'buildFlowFsm.changeOrderDecisionCatalogue.cmdUpdateChangeOrderDecision';
export const cmdDeleteChangeOrderDecisionRoute = 'buildFlowFsm.changeOrderDecisionCatalogue.cmdDeleteChangeOrderDecision';
export const qryChangeOrderPickerRoute = 'buildFlowFsm.changeOrderDecisionCatalogue.qryChangeOrderPicker';
