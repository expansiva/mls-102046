/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/clientBillingSummaryView.ts" enhancement="_blank"/>
export const qryClientBillingSummaryViewRoute = 'buildFlowFsm.clientBillingSummaryView.qryClientBillingSummaryView';
