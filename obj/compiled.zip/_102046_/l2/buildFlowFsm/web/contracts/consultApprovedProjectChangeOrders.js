/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/consultApprovedProjectChangeOrders.ts" enhancement="_blank"/>
export const qryLocateProjectRoute = 'buildFlowFsm.consultApprovedProjectChangeOrders.qryLocateProject';
export const qryInspectApprovedChangeOrdersRoute = 'buildFlowFsm.consultApprovedProjectChangeOrders.qryInspectApprovedChangeOrders';
export const qryInspectClientBillingSummaryRoute = 'buildFlowFsm.consultApprovedProjectChangeOrders.qryInspectClientBillingSummary';
