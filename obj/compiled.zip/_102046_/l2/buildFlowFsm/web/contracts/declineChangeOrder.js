/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/declineChangeOrder.ts" enhancement="_blank"/>
export const qryLocateChangeOrderRoute = 'buildFlowFsm.declineChangeOrder.qryLocateChangeOrder';
export const cmdDeclineChangeOrderDecisionRoute = 'buildFlowFsm.declineChangeOrder.cmdDeclineChangeOrderDecision';
export const cmdHandoffDeclinedChangeOrderToFieldCoordinatorRoute = 'buildFlowFsm.declineChangeOrder.cmdHandoffDeclinedChangeOrderToFieldCoordinator';
export const qryClientPickerRoute = 'buildFlowFsm.declineChangeOrder.qryClientPicker';
