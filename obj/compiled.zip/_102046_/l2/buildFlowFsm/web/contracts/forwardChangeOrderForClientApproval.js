/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/forwardChangeOrderForClientApproval.ts" enhancement="_blank"/>
export const qryLocateChangeOrderRoute = 'buildFlowFsm.forwardChangeOrderForClientApproval.qryLocateChangeOrder';
export const cmdHandoffChangeOrderToClientRoute = 'buildFlowFsm.forwardChangeOrderForClientApproval.cmdHandoffChangeOrderToClient';
