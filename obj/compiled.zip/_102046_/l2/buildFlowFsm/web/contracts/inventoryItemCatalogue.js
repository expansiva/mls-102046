/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/inventoryItemCatalogue.ts" enhancement="_blank"/>
export const qryListInventoryItemRoute = 'buildFlowFsm.inventoryItemCatalogue.qryListInventoryItem';
export const cmdCreateInventoryItemRoute = 'buildFlowFsm.inventoryItemCatalogue.cmdCreateInventoryItem';
export const cmdUpdateInventoryItemRoute = 'buildFlowFsm.inventoryItemCatalogue.cmdUpdateInventoryItem';
export const cmdDeleteInventoryItemRoute = 'buildFlowFsm.inventoryItemCatalogue.cmdDeleteInventoryItem';
