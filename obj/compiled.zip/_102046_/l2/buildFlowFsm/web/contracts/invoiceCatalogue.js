/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/invoiceCatalogue.ts" enhancement="_blank"/>
export const qryListInvoiceRoute = 'buildFlowFsm.invoiceCatalogue.qryListInvoice';
export const cmdCreateInvoiceRoute = 'buildFlowFsm.invoiceCatalogue.cmdCreateInvoice';
export const cmdUpdateInvoiceRoute = 'buildFlowFsm.invoiceCatalogue.cmdUpdateInvoice';
export const cmdDeleteInvoiceRoute = 'buildFlowFsm.invoiceCatalogue.cmdDeleteInvoice';
export const qryClientPickerRoute = 'buildFlowFsm.invoiceCatalogue.qryClientPicker';
export const qryProjectPickerRoute = 'buildFlowFsm.invoiceCatalogue.qryProjectPicker';
