/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/invoiceChangeOrderCatalogue.ts" enhancement="_blank"/>
export const qryListInvoiceChangeOrderRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.qryListInvoiceChangeOrder';
export const cmdCreateInvoiceChangeOrderRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.cmdCreateInvoiceChangeOrder';
export const cmdUpdateInvoiceChangeOrderRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.cmdUpdateInvoiceChangeOrder';
export const cmdDeleteInvoiceChangeOrderRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.cmdDeleteInvoiceChangeOrder';
export const qryInvoicePickerRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.qryInvoicePicker';
export const qryChangeOrderPickerRoute = 'buildFlowFsm.invoiceChangeOrderCatalogue.qryChangeOrderPicker';
