/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/monitorDailyProjectRecords.ts" enhancement="_blank"/>
export const qryLocateProjectRoute = 'buildFlowFsm.monitorDailyProjectRecords.qryLocateProject';
export const qryInspectProjectTimeLogsRoute = 'buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectTimeLogs';
export const qryInspectProjectMaterialUsagesRoute = 'buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectMaterialUsages';
export const qryInspectProjectExecutionOverviewRoute = 'buildFlowFsm.monitorDailyProjectRecords.qryInspectProjectExecutionOverview';
