/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/projectHub.ts" enhancement="_blank"/>
export const qryListProjectRoute = 'buildFlowFsm.projectHub.qryListProject';
export const qryClientBillingSummaryViewRoute = 'buildFlowFsm.projectHub.qryClientBillingSummaryView';
export const qryProjectDashboardViewRoute = 'buildFlowFsm.projectHub.qryProjectDashboardView';
export const qryProjectExecutionOverviewViewRoute = 'buildFlowFsm.projectHub.qryProjectExecutionOverviewView';
export const qryProjectTimelineViewRoute = 'buildFlowFsm.projectHub.qryProjectTimelineView';
export const qryScheduleRiskAssessmentViewRoute = 'buildFlowFsm.projectHub.qryScheduleRiskAssessmentView';
export const qryListChangeOrderRoute = 'buildFlowFsm.projectHub.qryListChangeOrder';
export const qryListInvoiceRoute = 'buildFlowFsm.projectHub.qryListInvoice';
export const qryListMaterialUsageRoute = 'buildFlowFsm.projectHub.qryListMaterialUsage';
export const qryListProjectCoordinationAssignmentRoute = 'buildFlowFsm.projectHub.qryListProjectCoordinationAssignment';
export const qryListStatusReportRoute = 'buildFlowFsm.projectHub.qryListStatusReport';
export const qryListWorkTaskRoute = 'buildFlowFsm.projectHub.qryListWorkTask';
