/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/projectTimelineView.ts" enhancement="_blank"/>
export const qryProjectTimelineViewRoute = 'buildFlowFsm.projectTimelineView.qryProjectTimelineView';
