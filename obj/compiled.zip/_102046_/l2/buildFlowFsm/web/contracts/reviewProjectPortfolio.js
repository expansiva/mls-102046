/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/reviewProjectPortfolio.ts" enhancement="_blank"/>
export const qryInspectProjectDashboardRoute = 'buildFlowFsm.reviewProjectPortfolio.qryInspectProjectDashboard';
export const qryLocateProjectRoute = 'buildFlowFsm.reviewProjectPortfolio.qryLocateProject';
export const qryInspectProjectExecutionOverviewRoute = 'buildFlowFsm.reviewProjectPortfolio.qryInspectProjectExecutionOverview';
export const cmdHandoffProjectToFieldCoordinatorRoute = 'buildFlowFsm.reviewProjectPortfolio.cmdHandoffProjectToFieldCoordinator';
