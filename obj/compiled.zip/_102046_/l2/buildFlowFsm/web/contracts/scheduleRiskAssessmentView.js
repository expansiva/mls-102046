/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/scheduleRiskAssessmentView.ts" enhancement="_blank"/>
export const qryScheduleRiskAssessmentViewRoute = 'buildFlowFsm.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView';
