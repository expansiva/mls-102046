/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/statusReportCatalogue.ts" enhancement="_blank"/>
export const qryListStatusReportRoute = 'buildFlowFsm.statusReportCatalogue.qryListStatusReport';
export const cmdCreateStatusReportRoute = 'buildFlowFsm.statusReportCatalogue.cmdCreateStatusReport';
export const cmdUpdateStatusReportRoute = 'buildFlowFsm.statusReportCatalogue.cmdUpdateStatusReport';
export const cmdDeleteStatusReportRoute = 'buildFlowFsm.statusReportCatalogue.cmdDeleteStatusReport';
export const qryProjectPickerRoute = 'buildFlowFsm.statusReportCatalogue.qryProjectPicker';
