/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/submitChangeOrder.ts" enhancement="_blank"/>
export const qryLocateClientRoute = 'buildFlowFsm.submitChangeOrder.qryLocateClient';
export const qryLocateProjectRoute = 'buildFlowFsm.submitChangeOrder.qryLocateProject';
export const cmdCreateChangeOrderRoute = 'buildFlowFsm.submitChangeOrder.cmdCreateChangeOrder';
export const cmdHandoffChangeOrderToProjectManagerRoute = 'buildFlowFsm.submitChangeOrder.cmdHandoffChangeOrderToProjectManager';
