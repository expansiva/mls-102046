/// <mls fileReference="_102046_/l2/buildFlowFsm/web/contracts/updateWorkTaskProgress.ts" enhancement="_blank"/>
export const qryLocateWorkTaskRoute = 'buildFlowFsm.updateWorkTaskProgress.qryLocateWorkTask';
export const cmdUpdateWorkTaskRoute = 'buildFlowFsm.updateWorkTaskProgress.cmdUpdateWorkTask';
export const cmdHandoffWorkTaskProgressToFieldCoordinatorRoute = 'buildFlowFsm.updateWorkTaskProgress.cmdHandoffWorkTaskProgressToFieldCoordinator';
