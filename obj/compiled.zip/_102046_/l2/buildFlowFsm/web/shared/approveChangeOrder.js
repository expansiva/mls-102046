/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/approveChangeOrder.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryLocateChangeOrderRoute, cmdApproveChangeOrderDecisionRoute, cmdHandoffApprovedChangeOrderToBillingRoute, qryClientPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/approveChangeOrder.js';
/// **collab_i18n_start**
const message_pt = {
    'section.approveChangeOrder.locateChangeOrder.title': 'Ordem pendente',
    'organism.approveChangeOrder.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.approveChangeOrder.approveChangeOrderDecision.title': 'Decisão de aprovação',
    'organism.approveChangeOrder.cmdApproveChangeOrderDecision.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.action.cmdApproveChangeOrderDecision': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.field.status.label': 'Status',
    'organism.approveChangeOrder.qryClientPicker.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'section.approveChangeOrder.handoffApprovedChangeOrderToBilling.title': 'Encaminhamento ao faturamento',
    'organism.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.action.cmdHandoffApprovedChangeOrderToBilling': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.description.label': 'Description',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.changeAmount.label': 'Change Amount',
    'action.cmdApproveChangeOrderDecision.success': 'Aprovar a ordem de mudança: OK',
    'action.cmdApproveChangeOrderDecision.error': 'Aprovar a ordem de mudança: falhou',
    'action.cmdHandoffApprovedChangeOrderToBilling.success': 'Encaminhar a alteração aprovada ao faturamento: OK',
    'action.cmdHandoffApprovedChangeOrderToBilling.error': 'Encaminhar a alteração aprovada ao faturamento: falhou',
    'section.approveChangeOrder.change-order-workspace.title': 'Revisar e decidir ordem de mudança',
    'section.approveChangeOrder.billing-handoff.title': 'Encaminhar aprovação ao faturamento',
};
const message_pt_br = {
    'section.approveChangeOrder.locateChangeOrder.title': 'Ordem pendente',
    'organism.approveChangeOrder.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.approveChangeOrder.approveChangeOrderDecision.title': 'Decisão de aprovação',
    'organism.approveChangeOrder.cmdApproveChangeOrderDecision.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.action.cmdApproveChangeOrderDecision': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.field.status.label': 'Status',
    'organism.approveChangeOrder.qryClientPicker.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'section.approveChangeOrder.handoffApprovedChangeOrderToBilling.title': 'Encaminhamento ao faturamento',
    'organism.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.action.cmdHandoffApprovedChangeOrderToBilling': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.description.label': 'Description',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.changeAmount.label': 'Change Amount',
    'action.cmdApproveChangeOrderDecision.success': 'Aprovar a ordem de mudança: OK',
    'action.cmdApproveChangeOrderDecision.error': 'Aprovar a ordem de mudança: falhou',
    'action.cmdHandoffApprovedChangeOrderToBilling.success': 'Encaminhar a alteração aprovada ao faturamento: OK',
    'action.cmdHandoffApprovedChangeOrderToBilling.error': 'Encaminhar a alteração aprovada ao faturamento: falhou',
    'section.approveChangeOrder.change-order-workspace.title': 'Revisar e decidir ordem de mudança',
    'section.approveChangeOrder.billing-handoff.title': 'Encaminhar aprovação ao faturamento',
};
const message_en = {
    'section.approveChangeOrder.locateChangeOrder.title': 'Ordem pendente',
    'organism.approveChangeOrder.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.approveChangeOrder.approveChangeOrderDecision.title': 'Decisão de aprovação',
    'organism.approveChangeOrder.cmdApproveChangeOrderDecision.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.action.cmdApproveChangeOrderDecision': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.field.status.label': 'Status',
    'organism.approveChangeOrder.qryClientPicker.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'section.approveChangeOrder.handoffApprovedChangeOrderToBilling.title': 'Encaminhamento ao faturamento',
    'organism.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.action.cmdHandoffApprovedChangeOrderToBilling': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.description.label': 'Description',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.changeAmount.label': 'Change Amount',
    'action.cmdApproveChangeOrderDecision.success': 'Aprovar a ordem de mudança: OK',
    'action.cmdApproveChangeOrderDecision.error': 'Aprovar a ordem de mudança: falhou',
    'action.cmdHandoffApprovedChangeOrderToBilling.success': 'Encaminhar a alteração aprovada ao faturamento: OK',
    'action.cmdHandoffApprovedChangeOrderToBilling.error': 'Encaminhar a alteração aprovada ao faturamento: falhou',
    'section.approveChangeOrder.change-order-workspace.title': 'Revisar e decidir ordem de mudança',
    'section.approveChangeOrder.billing-handoff.title': 'Encaminhar aprovação ao faturamento',
};
const message_es = {
    'section.approveChangeOrder.locateChangeOrder.title': 'Ordem pendente',
    'organism.approveChangeOrder.qryLocateChangeOrder.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.title': 'Localizar a ordem de mudança submetida',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeOrderId.label': 'Change Order Id',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.clientRef.label': 'Client Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.projectRef.label': 'Project Ref',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.description.label': 'Description',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.changeAmount.label': 'Change Amount',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.submittedAt.label': 'Submitted At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.forwardedForClientApprovalAt.label': 'Forwarded For Client Approval At',
    'intent.approveChangeOrder.qryLocateChangeOrder.list.column.status.label': 'Status',
    'section.approveChangeOrder.approveChangeOrderDecision.title': 'Decisão de aprovação',
    'organism.approveChangeOrder.cmdApproveChangeOrderDecision.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.title': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.action.cmdApproveChangeOrderDecision': 'Aprovar a ordem de mudança',
    'intent.approveChangeOrder.cmdApproveChangeOrderDecision.form.field.status.label': 'Status',
    'organism.approveChangeOrder.qryClientPicker.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.title': 'Listar Cliente',
    'intent.approveChangeOrder.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.approveChangeOrder.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.approveChangeOrder.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'section.approveChangeOrder.handoffApprovedChangeOrderToBilling.title': 'Encaminhamento ao faturamento',
    'organism.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.title': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.action.cmdHandoffApprovedChangeOrderToBilling': 'Encaminhar a alteração aprovada ao faturamento',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.description.label': 'Description',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scopeImpact.label': 'Scope Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.scheduleImpact.label': 'Schedule Impact',
    'intent.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling.form.field.changeAmount.label': 'Change Amount',
    'action.cmdApproveChangeOrderDecision.success': 'Aprovar a ordem de mudança: OK',
    'action.cmdApproveChangeOrderDecision.error': 'Aprovar a ordem de mudança: falhou',
    'action.cmdHandoffApprovedChangeOrderToBilling.success': 'Encaminhar a alteração aprovada ao faturamento: OK',
    'action.cmdHandoffApprovedChangeOrderToBilling.error': 'Encaminhar a alteração aprovada ao faturamento: falhou',
    'section.approveChangeOrder.change-order-workspace.title': 'Revisar e decidir ordem de mudança',
    'section.approveChangeOrder.billing-handoff.title': 'Encaminhar aprovação ao faturamento',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.approveChangeOrder.status',
    'ui.approveChangeOrder.action.qryLocateChangeOrder.status',
    'ui.approveChangeOrder.data.qryLocateChangeOrder',
    'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status',
    'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId',
    'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId',
    'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId',
    'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status',
    'ui.approveChangeOrder.output.cmdApproveChangeOrderDecision',
    'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error',
    'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status',
    'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId',
    'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description',
    'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact',
    'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact',
    'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount',
    'ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling',
    'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error',
    'ui.approveChangeOrder.action.qryClientPicker.status',
    'ui.approveChangeOrder.data.qryClientPicker',
];
export class BuildFlowFsmApproveChangeOrderBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryLocateChangeOrderState — actionStatus, values: idle|loading|success|error */
        this.qryLocateChangeOrderState = 'idle';
        /** state qryLocateChangeOrderData — queryResult, outputShape: array */
        this.qryLocateChangeOrderData = [];
        /** state cmdApproveChangeOrderDecisionState — actionStatus, values: idle|loading|success|error */
        this.cmdApproveChangeOrderDecisionState = 'idle';
        /** state cmdApproveChangeOrderDecisionChangeOrderChangeOrderId — input */
        this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId = '';
        /** state cmdApproveChangeOrderDecisionClientClientId — input */
        this.cmdApproveChangeOrderDecisionClientClientId = '';
        /** state cmdApproveChangeOrderDecisionProjectProjectId — input */
        this.cmdApproveChangeOrderDecisionProjectProjectId = '';
        /** state cmdApproveChangeOrderDecisionStatus — input */
        this.cmdApproveChangeOrderDecisionStatus = '';
        /** state cmdApproveChangeOrderDecisionOutput — commandOutput */
        this.cmdApproveChangeOrderDecisionOutput = null;
        /** state cmdApproveChangeOrderDecisionError — actionError */
        this.cmdApproveChangeOrderDecisionError = '';
        /** state cmdHandoffApprovedChangeOrderToBillingState — actionStatus, values: idle|loading|success|error */
        this.cmdHandoffApprovedChangeOrderToBillingState = 'idle';
        /** state cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId — input */
        this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId = '';
        /** state cmdHandoffApprovedChangeOrderToBillingDescription — input */
        this.cmdHandoffApprovedChangeOrderToBillingDescription = '';
        /** state cmdHandoffApprovedChangeOrderToBillingScopeImpact — input */
        this.cmdHandoffApprovedChangeOrderToBillingScopeImpact = '';
        /** state cmdHandoffApprovedChangeOrderToBillingScheduleImpact — input */
        this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact = '';
        /** state cmdHandoffApprovedChangeOrderToBillingChangeAmount — input */
        this.cmdHandoffApprovedChangeOrderToBillingChangeAmount = '';
        /** state cmdHandoffApprovedChangeOrderToBillingOutput — commandOutput */
        this.cmdHandoffApprovedChangeOrderToBillingOutput = null;
        /** state cmdHandoffApprovedChangeOrderToBillingError — actionError */
        this.cmdHandoffApprovedChangeOrderToBillingError = '';
        /** state qryClientPickerState — actionStatus, values: idle|loading|success|error */
        this.qryClientPickerState = 'idle';
        /** state qryClientPickerData — queryResult, outputShape: array */
        this.qryClientPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.approveChangeOrder.status', '');
        this.initStateValue('ui.approveChangeOrder.action.qryLocateChangeOrder.status', 'idle');
        this.initStateValue('ui.approveChangeOrder.data.qryLocateChangeOrder', []);
        this.initStateValue('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'idle');
        this.initStateValue('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status', '');
        this.initStateValue('ui.approveChangeOrder.output.cmdApproveChangeOrderDecision', null);
        this.initStateValue('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error', '');
        this.initStateValue('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'idle');
        this.initStateValue('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact', '');
        this.initStateValue('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount', '');
        this.initStateValue('ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling', null);
        this.initStateValue('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error', '');
        this.initStateValue('ui.approveChangeOrder.action.qryClientPicker.status', 'idle');
        this.initStateValue('ui.approveChangeOrder.data.qryClientPicker', []);
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryLocateChangeOrder();
        void this.loadQryClientPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.approveChangeOrder.status':
                this.status = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.qryLocateChangeOrder.status':
                this.qryLocateChangeOrderState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.data.qryLocateChangeOrder':
                this.qryLocateChangeOrderData = value ?? [];
                break;
            case 'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status':
                this.cmdApproveChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId':
                this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId':
                this.cmdApproveChangeOrderDecisionClientClientId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId':
                this.cmdApproveChangeOrderDecisionProjectProjectId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status':
                this.cmdApproveChangeOrderDecisionStatus = value ?? '';
                break;
            case 'ui.approveChangeOrder.output.cmdApproveChangeOrderDecision':
                this.cmdApproveChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error':
                this.cmdApproveChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status':
                this.cmdHandoffApprovedChangeOrderToBillingState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId':
                this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description':
                this.cmdHandoffApprovedChangeOrderToBillingDescription = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact':
                this.cmdHandoffApprovedChangeOrderToBillingScopeImpact = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact':
                this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount':
                this.cmdHandoffApprovedChangeOrderToBillingChangeAmount = value ?? '';
                break;
            case 'ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling':
                this.cmdHandoffApprovedChangeOrderToBillingOutput = value ?? null;
                break;
            case 'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error':
                this.cmdHandoffApprovedChangeOrderToBillingError = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.qryClientPicker.status':
                this.qryClientPickerState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.data.qryClientPicker':
                this.qryClientPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.approveChangeOrder.status':
                this.status = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.qryLocateChangeOrder.status':
                this.qryLocateChangeOrderState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.data.qryLocateChangeOrder':
                this.qryLocateChangeOrderData = value ?? [];
                break;
            case 'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status':
                this.cmdApproveChangeOrderDecisionState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId':
                this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId':
                this.cmdApproveChangeOrderDecisionClientClientId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId':
                this.cmdApproveChangeOrderDecisionProjectProjectId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status':
                this.cmdApproveChangeOrderDecisionStatus = value ?? '';
                break;
            case 'ui.approveChangeOrder.output.cmdApproveChangeOrderDecision':
                this.cmdApproveChangeOrderDecisionOutput = value ?? null;
                break;
            case 'ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error':
                this.cmdApproveChangeOrderDecisionError = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status':
                this.cmdHandoffApprovedChangeOrderToBillingState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId':
                this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description':
                this.cmdHandoffApprovedChangeOrderToBillingDescription = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact':
                this.cmdHandoffApprovedChangeOrderToBillingScopeImpact = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact':
                this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact = value ?? '';
                break;
            case 'ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount':
                this.cmdHandoffApprovedChangeOrderToBillingChangeAmount = value ?? '';
                break;
            case 'ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling':
                this.cmdHandoffApprovedChangeOrderToBillingOutput = value ?? null;
                break;
            case 'ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error':
                this.cmdHandoffApprovedChangeOrderToBillingError = value ?? '';
                break;
            case 'ui.approveChangeOrder.action.qryClientPicker.status':
                this.qryClientPickerState = value ?? 'idle';
                break;
            case 'ui.approveChangeOrder.data.qryClientPicker':
                this.qryClientPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/approveChangeOrder(?:\/([^/]+))?\/?$/);
        const rawProjectProjectId = match && match[1] ? match[1] : '';
        let projectProjectId = '';
        if (rawProjectProjectId) {
            try {
                projectProjectId = decodeURIComponent(rawProjectProjectId);
            }
            catch {
                projectProjectId = rawProjectProjectId;
            }
        }
        if (projectProjectId) {
            if (!this.cmdApproveChangeOrderDecisionProjectProjectId) {
                this.cmdApproveChangeOrderDecisionProjectProjectId = projectProjectId;
                setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId', projectProjectId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryLocateChangeOrder (query) — route buildFlowFsm.approveChangeOrder.qryLocateChangeOrder; inputs: (none); writes ui.approveChangeOrder.data.qryLocateChangeOrder; status ui.approveChangeOrder.action.qryLocateChangeOrder.status */
    async loadQryLocateChangeOrder() {
        this.syncRouteParams();
        this.qryLocateChangeOrderState = 'loading';
        setState('ui.approveChangeOrder.action.qryLocateChangeOrder.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateChangeOrderRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateChangeOrderData = data;
            setState('ui.approveChangeOrder.data.qryLocateChangeOrder', data);
            this.qryLocateChangeOrderState = 'success';
            setState('ui.approveChangeOrder.action.qryLocateChangeOrder.status', 'success');
        }
        else {
            this.qryLocateChangeOrderState = 'error';
            setState('ui.approveChangeOrder.action.qryLocateChangeOrder.status', 'error');
            if (response.error) {
                console.error('qryLocateChangeOrder failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateChangeOrder — bind UI events here */
    handleQryLocateChangeOrderClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateChangeOrder();
    }
    /** action cmdApproveChangeOrderDecision (command) — route buildFlowFsm.approveChangeOrder.cmdApproveChangeOrderDecision; inputs: changeOrderChangeOrderId, clientClientId, projectProjectId, status; writes ui.approveChangeOrder.output.cmdApproveChangeOrderDecision; status ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status; feedback keys action.cmdApproveChangeOrderDecision.success / action.cmdApproveChangeOrderDecision.error */
    async cmdApproveChangeOrderDecision() {
        this.syncRouteParams();
        if (!this.cmdApproveChangeOrderDecisionProjectProjectId) {
            this.cmdApproveChangeOrderDecisionState = 'idle';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId) {
            this.cmdApproveChangeOrderDecisionState = 'idle';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdApproveChangeOrderDecisionClientClientId) {
            this.cmdApproveChangeOrderDecisionState = 'idle';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdApproveChangeOrderDecisionState = 'loading';
        setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'loading');
        this.cmdApproveChangeOrderDecisionError = '';
        setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error', '');
        const params = {
            changeOrderChangeOrderId: this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId,
            clientClientId: this.cmdApproveChangeOrderDecisionClientClientId,
            projectProjectId: this.cmdApproveChangeOrderDecisionProjectProjectId,
            status: this.cmdApproveChangeOrderDecisionStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdApproveChangeOrderDecisionRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdApproveChangeOrderDecision.error');
            this.cmdApproveChangeOrderDecisionError = errMsg;
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.error', errMsg);
            this.cmdApproveChangeOrderDecisionState = 'error';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdApproveChangeOrderDecisionOutput = data;
        setState('ui.approveChangeOrder.output.cmdApproveChangeOrderDecision', data);
        try {
            await this.loadQryLocateChangeOrder();
            if (this.qryLocateChangeOrderState === 'error') {
                this.cmdApproveChangeOrderDecisionState = 'error';
                setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdApproveChangeOrderDecision refresh failed', refreshError);
            this.cmdApproveChangeOrderDecisionState = 'error';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryClientPicker();
            if (this.qryClientPickerState === 'error') {
                this.cmdApproveChangeOrderDecisionState = 'error';
                setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdApproveChangeOrderDecision refresh failed', refreshError);
            this.cmdApproveChangeOrderDecisionState = 'error';
            setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId = '';
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId', '');
        this.cmdApproveChangeOrderDecisionClientClientId = '';
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId', '');
        this.cmdApproveChangeOrderDecisionStatus = '';
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status', '');
        this.cmdApproveChangeOrderDecisionState = 'success';
        setState('ui.approveChangeOrder.action.cmdApproveChangeOrderDecision.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdApproveChangeOrderDecision — bind UI events here */
    handleCmdApproveChangeOrderDecisionClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdApproveChangeOrderDecision();
        });
    }
    /** action cmdHandoffApprovedChangeOrderToBilling (command) — route buildFlowFsm.approveChangeOrder.cmdHandoffApprovedChangeOrderToBilling; inputs: changeOrderChangeOrderId, description, scopeImpact, scheduleImpact, changeAmount; writes ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling; status ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status; feedback keys action.cmdHandoffApprovedChangeOrderToBilling.success / action.cmdHandoffApprovedChangeOrderToBilling.error */
    async cmdHandoffApprovedChangeOrderToBilling() {
        this.syncRouteParams();
        if (!this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId) {
            this.cmdHandoffApprovedChangeOrderToBillingState = 'idle';
            setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffApprovedChangeOrderToBillingState = 'loading';
        setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'loading');
        this.cmdHandoffApprovedChangeOrderToBillingError = '';
        setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error', '');
        const changeAmountNum = Number(this.cmdHandoffApprovedChangeOrderToBillingChangeAmount);
        const params = {
            changeOrderChangeOrderId: this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId,
            description: this.cmdHandoffApprovedChangeOrderToBillingDescription,
            scopeImpact: this.cmdHandoffApprovedChangeOrderToBillingScopeImpact,
            scheduleImpact: this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact,
            changeAmount: Number.isNaN(changeAmountNum) ? 0 : changeAmountNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdHandoffApprovedChangeOrderToBillingRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdHandoffApprovedChangeOrderToBilling.error');
            this.cmdHandoffApprovedChangeOrderToBillingError = errMsg;
            setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.error', errMsg);
            this.cmdHandoffApprovedChangeOrderToBillingState = 'error';
            setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdHandoffApprovedChangeOrderToBillingOutput = data;
        setState('ui.approveChangeOrder.output.cmdHandoffApprovedChangeOrderToBilling', data);
        try {
            await this.loadQryLocateChangeOrder();
            if (this.qryLocateChangeOrderState === 'error') {
                this.cmdHandoffApprovedChangeOrderToBillingState = 'error';
                setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdHandoffApprovedChangeOrderToBilling refresh failed', refreshError);
            this.cmdHandoffApprovedChangeOrderToBillingState = 'error';
            setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryClientPicker();
            if (this.qryClientPickerState === 'error') {
                this.cmdHandoffApprovedChangeOrderToBillingState = 'error';
                setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdHandoffApprovedChangeOrderToBilling refresh failed', refreshError);
            this.cmdHandoffApprovedChangeOrderToBillingState = 'error';
            setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId = '';
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId', '');
        this.cmdHandoffApprovedChangeOrderToBillingDescription = '';
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description', '');
        this.cmdHandoffApprovedChangeOrderToBillingScopeImpact = '';
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact', '');
        this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact = '';
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact', '');
        this.cmdHandoffApprovedChangeOrderToBillingChangeAmount = '';
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount', '');
        this.cmdHandoffApprovedChangeOrderToBillingState = 'success';
        setState('ui.approveChangeOrder.action.cmdHandoffApprovedChangeOrderToBilling.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdHandoffApprovedChangeOrderToBilling — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdHandoffApprovedChangeOrderToBilling();
        });
    }
    /** action qryClientPicker (query) — route buildFlowFsm.approveChangeOrder.qryClientPicker; inputs: (none); writes ui.approveChangeOrder.data.qryClientPicker; status ui.approveChangeOrder.action.qryClientPicker.status */
    async loadQryClientPicker() {
        this.syncRouteParams();
        this.qryClientPickerState = 'loading';
        setState('ui.approveChangeOrder.action.qryClientPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryClientPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryClientPickerData = data;
            setState('ui.approveChangeOrder.data.qryClientPicker', data);
            this.qryClientPickerState = 'success';
            setState('ui.approveChangeOrder.action.qryClientPicker.status', 'success');
        }
        else {
            this.qryClientPickerState = 'error';
            setState('ui.approveChangeOrder.action.qryClientPicker.status', 'error');
            if (response.error) {
                console.error('qryClientPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryClientPicker — bind UI events here */
    handleQryClientPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryClientPicker();
    }
    /** setter for state ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId */
    setCmdApproveChangeOrderDecisionChangeOrderChangeOrderId(value) {
        this.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId = value;
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.changeOrderChangeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdApproveChangeOrderDecisionChangeOrderChangeOrderId — bind UI events here */
    handleCmdApproveChangeOrderDecisionChangeOrderChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdApproveChangeOrderDecisionChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId */
    setCmdApproveChangeOrderDecisionClientClientId(value) {
        this.cmdApproveChangeOrderDecisionClientClientId = value;
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.clientClientId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdApproveChangeOrderDecisionClientClientId — bind UI events here */
    handleCmdApproveChangeOrderDecisionClientClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdApproveChangeOrderDecisionClientClientId(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId */
    setCmdApproveChangeOrderDecisionProjectProjectId(value) {
        this.cmdApproveChangeOrderDecisionProjectProjectId = value;
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.projectProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdApproveChangeOrderDecisionProjectProjectId — bind UI events here */
    handleCmdApproveChangeOrderDecisionProjectProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdApproveChangeOrderDecisionProjectProjectId(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status */
    setCmdApproveChangeOrderDecisionStatus(value) {
        this.cmdApproveChangeOrderDecisionStatus = value;
        setState('ui.approveChangeOrder.input.cmdApproveChangeOrderDecision.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdApproveChangeOrderDecisionStatus — bind UI events here */
    handleCmdApproveChangeOrderDecisionStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdApproveChangeOrderDecisionStatus(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId */
    setCmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId(value) {
        this.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId = value;
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeOrderChangeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description */
    setCmdHandoffApprovedChangeOrderToBillingDescription(value) {
        this.cmdHandoffApprovedChangeOrderToBillingDescription = value;
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffApprovedChangeOrderToBillingDescription — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffApprovedChangeOrderToBillingDescription(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact */
    setCmdHandoffApprovedChangeOrderToBillingScopeImpact(value) {
        this.cmdHandoffApprovedChangeOrderToBillingScopeImpact = value;
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scopeImpact', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffApprovedChangeOrderToBillingScopeImpact — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingScopeImpactChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffApprovedChangeOrderToBillingScopeImpact(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact */
    setCmdHandoffApprovedChangeOrderToBillingScheduleImpact(value) {
        this.cmdHandoffApprovedChangeOrderToBillingScheduleImpact = value;
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.scheduleImpact', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffApprovedChangeOrderToBillingScheduleImpact — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingScheduleImpactChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffApprovedChangeOrderToBillingScheduleImpact(value);
    }
    /** setter for state ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount */
    setCmdHandoffApprovedChangeOrderToBillingChangeAmount(value) {
        this.cmdHandoffApprovedChangeOrderToBillingChangeAmount = value;
        setState('ui.approveChangeOrder.input.cmdHandoffApprovedChangeOrderToBilling.changeAmount', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdHandoffApprovedChangeOrderToBillingChangeAmount — bind UI events here */
    handleCmdHandoffApprovedChangeOrderToBillingChangeAmountChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdHandoffApprovedChangeOrderToBillingChangeAmount(value);
    }
}
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "qryLocateChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "qryLocateChangeOrderData", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionState", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionChangeOrderChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionClientClientId", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionProjectProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionStatus", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionOutput", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdApproveChangeOrderDecisionError", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingState", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingChangeOrderChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingDescription", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingScopeImpact", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingScheduleImpact", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingChangeAmount", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingOutput", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "cmdHandoffApprovedChangeOrderToBillingError", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "qryClientPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmApproveChangeOrderBase.prototype, "qryClientPickerData", void 0);
