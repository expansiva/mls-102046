/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/clientCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListClientRoute, cmdCreateClientRoute, cmdUpdateClientRoute, cmdDeleteClientRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/clientCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.clientCatalogue.recordList.title': 'Localizar Cliente',
    'organism.clientCatalogue.qryListClient.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.empty': 'Nenhum registro encontrado',
    'intent.clientCatalogue.qryListClient.list.column.clientId.label': 'Client Id',
    'intent.clientCatalogue.qryListClient.list.column.clientName.label': 'Client Name',
    'intent.clientCatalogue.qryListClient.list.column.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.qryListClient.list.column.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdDeleteClient.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.action.cmdDeleteClient': 'Excluir Cliente',
    'section.clientCatalogue.recordForm.title': 'Criar ou corrigir Cliente',
    'organism.clientCatalogue.cmdCreateClient.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.action.cmdCreateClient': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdUpdateClient.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.action.cmdUpdateClient': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactPhone.label': 'Contact Phone',
    'action.cmdCreateClient.success': 'Criar Cliente: OK',
    'action.cmdCreateClient.error': 'Criar Cliente: falhou',
    'action.cmdUpdateClient.success': 'Atualizar Cliente: OK',
    'action.cmdUpdateClient.error': 'Atualizar Cliente: falhou',
    'action.cmdDeleteClient.success': 'Excluir Cliente: OK',
    'action.cmdDeleteClient.error': 'Excluir Cliente: falhou',
    'section.clientCatalogue.clientWorkspace.title': 'Gestão de clientes',
};
const message_pt_br = {
    'section.clientCatalogue.recordList.title': 'Localizar Cliente',
    'organism.clientCatalogue.qryListClient.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.empty': 'Nenhum registro encontrado',
    'intent.clientCatalogue.qryListClient.list.column.clientId.label': 'Client Id',
    'intent.clientCatalogue.qryListClient.list.column.clientName.label': 'Client Name',
    'intent.clientCatalogue.qryListClient.list.column.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.qryListClient.list.column.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdDeleteClient.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.action.cmdDeleteClient': 'Excluir Cliente',
    'section.clientCatalogue.recordForm.title': 'Criar ou corrigir Cliente',
    'organism.clientCatalogue.cmdCreateClient.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.action.cmdCreateClient': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdUpdateClient.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.action.cmdUpdateClient': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactPhone.label': 'Contact Phone',
    'action.cmdCreateClient.success': 'Criar Cliente: OK',
    'action.cmdCreateClient.error': 'Criar Cliente: falhou',
    'action.cmdUpdateClient.success': 'Atualizar Cliente: OK',
    'action.cmdUpdateClient.error': 'Atualizar Cliente: falhou',
    'action.cmdDeleteClient.success': 'Excluir Cliente: OK',
    'action.cmdDeleteClient.error': 'Excluir Cliente: falhou',
    'section.clientCatalogue.clientWorkspace.title': 'Gestão de clientes',
};
const message_en = {
    'section.clientCatalogue.recordList.title': 'Localizar Cliente',
    'organism.clientCatalogue.qryListClient.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.empty': 'Nenhum registro encontrado',
    'intent.clientCatalogue.qryListClient.list.column.clientId.label': 'Client Id',
    'intent.clientCatalogue.qryListClient.list.column.clientName.label': 'Client Name',
    'intent.clientCatalogue.qryListClient.list.column.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.qryListClient.list.column.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdDeleteClient.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.action.cmdDeleteClient': 'Excluir Cliente',
    'section.clientCatalogue.recordForm.title': 'Criar ou corrigir Cliente',
    'organism.clientCatalogue.cmdCreateClient.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.action.cmdCreateClient': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdUpdateClient.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.action.cmdUpdateClient': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactPhone.label': 'Contact Phone',
    'action.cmdCreateClient.success': 'Criar Cliente: OK',
    'action.cmdCreateClient.error': 'Criar Cliente: falhou',
    'action.cmdUpdateClient.success': 'Atualizar Cliente: OK',
    'action.cmdUpdateClient.error': 'Atualizar Cliente: falhou',
    'action.cmdDeleteClient.success': 'Excluir Cliente: OK',
    'action.cmdDeleteClient.error': 'Excluir Cliente: falhou',
    'section.clientCatalogue.clientWorkspace.title': 'Gestão de clientes',
};
const message_es = {
    'section.clientCatalogue.recordList.title': 'Localizar Cliente',
    'organism.clientCatalogue.qryListClient.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.title': 'Listar Cliente',
    'intent.clientCatalogue.qryListClient.list.empty': 'Nenhum registro encontrado',
    'intent.clientCatalogue.qryListClient.list.column.clientId.label': 'Client Id',
    'intent.clientCatalogue.qryListClient.list.column.clientName.label': 'Client Name',
    'intent.clientCatalogue.qryListClient.list.column.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.qryListClient.list.column.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdDeleteClient.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.title': 'Excluir Cliente',
    'intent.clientCatalogue.cmdDeleteClient.form.action.cmdDeleteClient': 'Excluir Cliente',
    'section.clientCatalogue.recordForm.title': 'Criar ou corrigir Cliente',
    'organism.clientCatalogue.cmdCreateClient.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.title': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.action.cmdCreateClient': 'Criar Cliente',
    'intent.clientCatalogue.cmdCreateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdCreateClient.form.field.contactPhone.label': 'Contact Phone',
    'organism.clientCatalogue.cmdUpdateClient.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.title': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.action.cmdUpdateClient': 'Atualizar Cliente',
    'intent.clientCatalogue.cmdUpdateClient.form.field.clientName.label': 'Client Name',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactEmail.label': 'Contact Email',
    'intent.clientCatalogue.cmdUpdateClient.form.field.contactPhone.label': 'Contact Phone',
    'action.cmdCreateClient.success': 'Criar Cliente: OK',
    'action.cmdCreateClient.error': 'Criar Cliente: falhou',
    'action.cmdUpdateClient.success': 'Atualizar Cliente: OK',
    'action.cmdUpdateClient.error': 'Atualizar Cliente: falhou',
    'action.cmdDeleteClient.success': 'Excluir Cliente: OK',
    'action.cmdDeleteClient.error': 'Excluir Cliente: falhou',
    'section.clientCatalogue.clientWorkspace.title': 'Gestão de clientes',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.clientCatalogue.status',
    'ui.clientCatalogue.action.qryListClient.status',
    'ui.clientCatalogue.data.qryListClient',
    'ui.clientCatalogue.action.cmdCreateClient.status',
    'ui.clientCatalogue.input.cmdCreateClient.clientName',
    'ui.clientCatalogue.input.cmdCreateClient.contactEmail',
    'ui.clientCatalogue.input.cmdCreateClient.contactPhone',
    'ui.clientCatalogue.output.cmdCreateClient',
    'ui.clientCatalogue.action.cmdCreateClient.error',
    'ui.clientCatalogue.action.cmdUpdateClient.status',
    'ui.clientCatalogue.input.cmdUpdateClient.clientId',
    'ui.clientCatalogue.input.cmdUpdateClient.clientName',
    'ui.clientCatalogue.input.cmdUpdateClient.contactEmail',
    'ui.clientCatalogue.input.cmdUpdateClient.contactPhone',
    'ui.clientCatalogue.output.cmdUpdateClient',
    'ui.clientCatalogue.action.cmdUpdateClient.error',
    'ui.clientCatalogue.action.cmdDeleteClient.status',
    'ui.clientCatalogue.input.cmdDeleteClient.clientId',
    'ui.clientCatalogue.output.cmdDeleteClient',
    'ui.clientCatalogue.action.cmdDeleteClient.error',
];
export class BuildFlowFsmClientCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListClientState — actionStatus, values: idle|loading|success|error */
        this.qryListClientState = 'idle';
        /** state qryListClientData — queryResult, outputShape: array */
        this.qryListClientData = [];
        /** state cmdCreateClientState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateClientState = 'idle';
        /** state cmdCreateClientClientName — input */
        this.cmdCreateClientClientName = '';
        /** state cmdCreateClientContactEmail — input */
        this.cmdCreateClientContactEmail = '';
        /** state cmdCreateClientContactPhone — input */
        this.cmdCreateClientContactPhone = '';
        /** state cmdCreateClientOutput — commandOutput */
        this.cmdCreateClientOutput = null;
        /** state cmdCreateClientError — actionError */
        this.cmdCreateClientError = '';
        /** state cmdUpdateClientState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateClientState = 'idle';
        /** state cmdUpdateClientClientId — input */
        this.cmdUpdateClientClientId = '';
        /** state cmdUpdateClientClientName — input */
        this.cmdUpdateClientClientName = '';
        /** state cmdUpdateClientContactEmail — input */
        this.cmdUpdateClientContactEmail = '';
        /** state cmdUpdateClientContactPhone — input */
        this.cmdUpdateClientContactPhone = '';
        /** state cmdUpdateClientOutput — commandOutput */
        this.cmdUpdateClientOutput = null;
        /** state cmdUpdateClientError — actionError */
        this.cmdUpdateClientError = '';
        /** state cmdDeleteClientState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteClientState = 'idle';
        /** state cmdDeleteClientClientId — input */
        this.cmdDeleteClientClientId = '';
        /** state cmdDeleteClientOutput — commandOutput */
        this.cmdDeleteClientOutput = null;
        /** state cmdDeleteClientError — actionError */
        this.cmdDeleteClientError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.clientCatalogue.status', '');
        this.initStateValue('ui.clientCatalogue.action.qryListClient.status', 'idle');
        this.initStateValue('ui.clientCatalogue.data.qryListClient', []);
        this.initStateValue('ui.clientCatalogue.action.cmdCreateClient.status', 'idle');
        this.initStateValue('ui.clientCatalogue.input.cmdCreateClient.clientName', '');
        this.initStateValue('ui.clientCatalogue.input.cmdCreateClient.contactEmail', '');
        this.initStateValue('ui.clientCatalogue.input.cmdCreateClient.contactPhone', '');
        this.initStateValue('ui.clientCatalogue.output.cmdCreateClient', null);
        this.initStateValue('ui.clientCatalogue.action.cmdCreateClient.error', '');
        this.initStateValue('ui.clientCatalogue.action.cmdUpdateClient.status', 'idle');
        this.initStateValue('ui.clientCatalogue.input.cmdUpdateClient.clientId', '');
        this.initStateValue('ui.clientCatalogue.input.cmdUpdateClient.clientName', '');
        this.initStateValue('ui.clientCatalogue.input.cmdUpdateClient.contactEmail', '');
        this.initStateValue('ui.clientCatalogue.input.cmdUpdateClient.contactPhone', '');
        this.initStateValue('ui.clientCatalogue.output.cmdUpdateClient', null);
        this.initStateValue('ui.clientCatalogue.action.cmdUpdateClient.error', '');
        this.initStateValue('ui.clientCatalogue.action.cmdDeleteClient.status', 'idle');
        this.initStateValue('ui.clientCatalogue.input.cmdDeleteClient.clientId', '');
        this.initStateValue('ui.clientCatalogue.output.cmdDeleteClient', null);
        this.initStateValue('ui.clientCatalogue.action.cmdDeleteClient.error', '');
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListClient();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.clientCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.clientCatalogue.action.qryListClient.status':
                this.qryListClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.data.qryListClient':
                this.qryListClientData = value ?? [];
                break;
            case 'ui.clientCatalogue.action.cmdCreateClient.status':
                this.cmdCreateClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.clientName':
                this.cmdCreateClientClientName = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.contactEmail':
                this.cmdCreateClientContactEmail = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.contactPhone':
                this.cmdCreateClientContactPhone = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdCreateClient':
                this.cmdCreateClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdCreateClient.error':
                this.cmdCreateClientError = value ?? '';
                break;
            case 'ui.clientCatalogue.action.cmdUpdateClient.status':
                this.cmdUpdateClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.clientId':
                this.cmdUpdateClientClientId = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.clientName':
                this.cmdUpdateClientClientName = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.contactEmail':
                this.cmdUpdateClientContactEmail = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.contactPhone':
                this.cmdUpdateClientContactPhone = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdUpdateClient':
                this.cmdUpdateClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdUpdateClient.error':
                this.cmdUpdateClientError = value ?? '';
                break;
            case 'ui.clientCatalogue.action.cmdDeleteClient.status':
                this.cmdDeleteClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdDeleteClient.clientId':
                this.cmdDeleteClientClientId = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdDeleteClient':
                this.cmdDeleteClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdDeleteClient.error':
                this.cmdDeleteClientError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.clientCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.clientCatalogue.action.qryListClient.status':
                this.qryListClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.data.qryListClient':
                this.qryListClientData = value ?? [];
                break;
            case 'ui.clientCatalogue.action.cmdCreateClient.status':
                this.cmdCreateClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.clientName':
                this.cmdCreateClientClientName = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.contactEmail':
                this.cmdCreateClientContactEmail = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdCreateClient.contactPhone':
                this.cmdCreateClientContactPhone = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdCreateClient':
                this.cmdCreateClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdCreateClient.error':
                this.cmdCreateClientError = value ?? '';
                break;
            case 'ui.clientCatalogue.action.cmdUpdateClient.status':
                this.cmdUpdateClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.clientId':
                this.cmdUpdateClientClientId = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.clientName':
                this.cmdUpdateClientClientName = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.contactEmail':
                this.cmdUpdateClientContactEmail = value ?? '';
                break;
            case 'ui.clientCatalogue.input.cmdUpdateClient.contactPhone':
                this.cmdUpdateClientContactPhone = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdUpdateClient':
                this.cmdUpdateClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdUpdateClient.error':
                this.cmdUpdateClientError = value ?? '';
                break;
            case 'ui.clientCatalogue.action.cmdDeleteClient.status':
                this.cmdDeleteClientState = value ?? 'idle';
                break;
            case 'ui.clientCatalogue.input.cmdDeleteClient.clientId':
                this.cmdDeleteClientClientId = value ?? '';
                break;
            case 'ui.clientCatalogue.output.cmdDeleteClient':
                this.cmdDeleteClientOutput = value ?? null;
                break;
            case 'ui.clientCatalogue.action.cmdDeleteClient.error':
                this.cmdDeleteClientError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListClient (query) — route buildFlowFsm.clientCatalogue.qryListClient; inputs: (none); writes ui.clientCatalogue.data.qryListClient; status ui.clientCatalogue.action.qryListClient.status */
    async loadQryListClient() {
        this.qryListClientState = 'loading';
        setState('ui.clientCatalogue.action.qryListClient.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListClientRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListClientData = data;
            setState('ui.clientCatalogue.data.qryListClient', data);
            this.qryListClientState = 'success';
            setState('ui.clientCatalogue.action.qryListClient.status', 'success');
        }
        else {
            this.qryListClientState = 'error';
            setState('ui.clientCatalogue.action.qryListClient.status', 'error');
            if (response.error) {
                console.error('qryListClient failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListClient — bind UI events here */
    handleQryListClientClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListClient();
    }
    /** action cmdCreateClient (command) — route buildFlowFsm.clientCatalogue.cmdCreateClient; inputs: clientName, contactEmail, contactPhone; writes ui.clientCatalogue.output.cmdCreateClient; status ui.clientCatalogue.action.cmdCreateClient.status; feedback keys action.cmdCreateClient.success / action.cmdCreateClient.error */
    async cmdCreateClient() {
        this.cmdCreateClientState = 'loading';
        setState('ui.clientCatalogue.action.cmdCreateClient.status', 'loading');
        this.cmdCreateClientError = '';
        setState('ui.clientCatalogue.action.cmdCreateClient.error', '');
        const params = {
            clientName: this.cmdCreateClientClientName,
        };
        if (this.cmdCreateClientContactEmail) {
            params.contactEmail = this.cmdCreateClientContactEmail;
        }
        if (this.cmdCreateClientContactPhone) {
            params.contactPhone = this.cmdCreateClientContactPhone;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateClientRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateClient.error');
            this.cmdCreateClientError = errMsg;
            setState('ui.clientCatalogue.action.cmdCreateClient.error', errMsg);
            this.cmdCreateClientState = 'error';
            setState('ui.clientCatalogue.action.cmdCreateClient.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateClientOutput = data;
        setState('ui.clientCatalogue.output.cmdCreateClient', data);
        try {
            await this.loadQryListClient();
            if (this.qryListClientState === 'error') {
                this.cmdCreateClientState = 'error';
                setState('ui.clientCatalogue.action.cmdCreateClient.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateClient refresh failed', refreshError);
            this.cmdCreateClientState = 'error';
            setState('ui.clientCatalogue.action.cmdCreateClient.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateClientClientName = '';
        setState('ui.clientCatalogue.input.cmdCreateClient.clientName', '');
        this.cmdCreateClientContactEmail = '';
        setState('ui.clientCatalogue.input.cmdCreateClient.contactEmail', '');
        this.cmdCreateClientContactPhone = '';
        setState('ui.clientCatalogue.input.cmdCreateClient.contactPhone', '');
        this.cmdCreateClientState = 'success';
        setState('ui.clientCatalogue.action.cmdCreateClient.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateClient — bind UI events here */
    handleCmdCreateClientClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateClient();
        });
    }
    /** action cmdUpdateClient (command) — route buildFlowFsm.clientCatalogue.cmdUpdateClient; inputs: clientId, clientName, contactEmail, contactPhone; writes ui.clientCatalogue.output.cmdUpdateClient; status ui.clientCatalogue.action.cmdUpdateClient.status; feedback keys action.cmdUpdateClient.success / action.cmdUpdateClient.error */
    async cmdUpdateClient() {
        if (!this.cmdUpdateClientClientId) {
            this.cmdUpdateClientState = 'idle';
            setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateClientState = 'loading';
        setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'loading');
        this.cmdUpdateClientError = '';
        setState('ui.clientCatalogue.action.cmdUpdateClient.error', '');
        const params = {
            clientId: this.cmdUpdateClientClientId,
            clientName: this.cmdUpdateClientClientName,
        };
        if (this.cmdUpdateClientContactEmail) {
            params.contactEmail = this.cmdUpdateClientContactEmail;
        }
        if (this.cmdUpdateClientContactPhone) {
            params.contactPhone = this.cmdUpdateClientContactPhone;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateClientRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateClient.error');
            this.cmdUpdateClientError = errMsg;
            setState('ui.clientCatalogue.action.cmdUpdateClient.error', errMsg);
            this.cmdUpdateClientState = 'error';
            setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateClientOutput = data;
        setState('ui.clientCatalogue.output.cmdUpdateClient', data);
        try {
            await this.loadQryListClient();
            if (this.qryListClientState === 'error') {
                this.cmdUpdateClientState = 'error';
                setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateClient refresh failed', refreshError);
            this.cmdUpdateClientState = 'error';
            setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateClientClientId = '';
        setState('ui.clientCatalogue.input.cmdUpdateClient.clientId', '');
        this.cmdUpdateClientClientName = '';
        setState('ui.clientCatalogue.input.cmdUpdateClient.clientName', '');
        this.cmdUpdateClientContactEmail = '';
        setState('ui.clientCatalogue.input.cmdUpdateClient.contactEmail', '');
        this.cmdUpdateClientContactPhone = '';
        setState('ui.clientCatalogue.input.cmdUpdateClient.contactPhone', '');
        this.cmdUpdateClientState = 'success';
        setState('ui.clientCatalogue.action.cmdUpdateClient.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateClient — bind UI events here */
    handleCmdUpdateClientClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateClient();
        });
    }
    /** action cmdDeleteClient (command) — route buildFlowFsm.clientCatalogue.cmdDeleteClient; inputs: clientId; writes ui.clientCatalogue.output.cmdDeleteClient; status ui.clientCatalogue.action.cmdDeleteClient.status; feedback keys action.cmdDeleteClient.success / action.cmdDeleteClient.error */
    async cmdDeleteClient() {
        if (!this.cmdDeleteClientClientId) {
            this.cmdDeleteClientState = 'idle';
            setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteClientState = 'loading';
        setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'loading');
        this.cmdDeleteClientError = '';
        setState('ui.clientCatalogue.action.cmdDeleteClient.error', '');
        const params = {
            clientId: this.cmdDeleteClientClientId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteClientRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteClient.error');
            this.cmdDeleteClientError = errMsg;
            setState('ui.clientCatalogue.action.cmdDeleteClient.error', errMsg);
            this.cmdDeleteClientState = 'error';
            setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteClientOutput = data;
        setState('ui.clientCatalogue.output.cmdDeleteClient', data);
        try {
            await this.loadQryListClient();
            if (this.qryListClientState === 'error') {
                this.cmdDeleteClientState = 'error';
                setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteClient refresh failed', refreshError);
            this.cmdDeleteClientState = 'error';
            setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteClientClientId = '';
        setState('ui.clientCatalogue.input.cmdDeleteClient.clientId', '');
        this.cmdDeleteClientState = 'success';
        setState('ui.clientCatalogue.action.cmdDeleteClient.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteClient — bind UI events here */
    handleCmdDeleteClientClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteClient();
        });
    }
    /** setter for state ui.clientCatalogue.input.cmdCreateClient.clientName */
    setCmdCreateClientClientName(value) {
        this.cmdCreateClientClientName = value;
        setState('ui.clientCatalogue.input.cmdCreateClient.clientName', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateClientClientName — bind UI events here */
    handleCmdCreateClientClientNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateClientClientName(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdCreateClient.contactEmail */
    setCmdCreateClientContactEmail(value) {
        this.cmdCreateClientContactEmail = value;
        setState('ui.clientCatalogue.input.cmdCreateClient.contactEmail', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateClientContactEmail — bind UI events here */
    handleCmdCreateClientContactEmailChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateClientContactEmail(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdCreateClient.contactPhone */
    setCmdCreateClientContactPhone(value) {
        this.cmdCreateClientContactPhone = value;
        setState('ui.clientCatalogue.input.cmdCreateClient.contactPhone', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateClientContactPhone — bind UI events here */
    handleCmdCreateClientContactPhoneChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateClientContactPhone(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdUpdateClient.clientId */
    setCmdUpdateClientClientId(value) {
        this.cmdUpdateClientClientId = value;
        setState('ui.clientCatalogue.input.cmdUpdateClient.clientId', value);
        const collection = getState('ui.clientCatalogue.data.qryListClient') ?? this.qryListClientData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.clientId) === String(value));
            if (item) {
                this.cmdUpdateClientClientName = item.clientName;
                setState('ui.clientCatalogue.input.cmdUpdateClient.clientName', item.clientName);
                this.cmdUpdateClientContactEmail = item.contactEmail;
                setState('ui.clientCatalogue.input.cmdUpdateClient.contactEmail', item.contactEmail);
                this.cmdUpdateClientContactPhone = item.contactPhone;
                setState('ui.clientCatalogue.input.cmdUpdateClient.contactPhone', item.contactPhone);
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateClientClientId — bind UI events here */
    handleCmdUpdateClientClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateClientClientId(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdUpdateClient.clientName */
    setCmdUpdateClientClientName(value) {
        this.cmdUpdateClientClientName = value;
        setState('ui.clientCatalogue.input.cmdUpdateClient.clientName', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateClientClientName — bind UI events here */
    handleCmdUpdateClientClientNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateClientClientName(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdUpdateClient.contactEmail */
    setCmdUpdateClientContactEmail(value) {
        this.cmdUpdateClientContactEmail = value;
        setState('ui.clientCatalogue.input.cmdUpdateClient.contactEmail', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateClientContactEmail — bind UI events here */
    handleCmdUpdateClientContactEmailChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateClientContactEmail(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdUpdateClient.contactPhone */
    setCmdUpdateClientContactPhone(value) {
        this.cmdUpdateClientContactPhone = value;
        setState('ui.clientCatalogue.input.cmdUpdateClient.contactPhone', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateClientContactPhone — bind UI events here */
    handleCmdUpdateClientContactPhoneChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateClientContactPhone(value);
    }
    /** setter for state ui.clientCatalogue.input.cmdDeleteClient.clientId */
    setCmdDeleteClientClientId(value) {
        this.cmdDeleteClientClientId = value;
        setState('ui.clientCatalogue.input.cmdDeleteClient.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteClientClientId — bind UI events here */
    handleCmdDeleteClientClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteClientClientId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "qryListClientState", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "qryListClientData", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientState", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientClientName", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientContactEmail", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientContactPhone", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientOutput", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdCreateClientError", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientState", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientClientId", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientClientName", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientContactEmail", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientContactPhone", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientOutput", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdUpdateClientError", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdDeleteClientState", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdDeleteClientClientId", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdDeleteClientOutput", void 0);
__decorate([
    property()
], BuildFlowFsmClientCatalogueBase.prototype, "cmdDeleteClientError", void 0);
