/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/projectCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListProjectRoute, cmdCreateProjectRoute, cmdUpdateProjectRoute, cmdDeleteProjectRoute, qryClientPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/projectCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.projectCatalogue.recordList.title': 'Localizar obra',
    'organism.projectCatalogue.qryListProject.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryListProject.list.column.projectId.label': 'Project Id',
    'intent.projectCatalogue.qryListProject.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryListProject.list.column.name.label': 'Name',
    'intent.projectCatalogue.qryListProject.list.column.address.label': 'Address',
    'intent.projectCatalogue.qryListProject.list.column.status.label': 'Status',
    'intent.projectCatalogue.qryListProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.qryListProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.qryListProject.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdDeleteProject.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.action.cmdDeleteProject': 'Excluir Obra',
    'section.projectCatalogue.recordForm.title': 'Criar ou corrigir obra',
    'organism.projectCatalogue.cmdCreateProject.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.action.cmdCreateProject': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdCreateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdCreateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdCreateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdCreateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdUpdateProject.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.action.cmdUpdateProject': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdUpdateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdUpdateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdUpdateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdUpdateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.qryClientPicker.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.projectCatalogue.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.projectCatalogue.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'action.cmdCreateProject.success': 'Criar Obra: OK',
    'action.cmdCreateProject.error': 'Criar Obra: falhou',
    'action.cmdUpdateProject.success': 'Atualizar Obra: OK',
    'action.cmdUpdateProject.error': 'Atualizar Obra: falhou',
    'action.cmdDeleteProject.success': 'Excluir Obra: OK',
    'action.cmdDeleteProject.error': 'Excluir Obra: falhou',
    'section.projectCatalogue.projectWorkbench.title': 'Obras',
    'section.projectCatalogue.projectCreation.title': 'Nova obra',
    'section.projectCatalogue.projectWorkspace.title': 'Localização e manutenção de obras',
};
const message_pt_br = {
    'section.projectCatalogue.recordList.title': 'Localizar obra',
    'organism.projectCatalogue.qryListProject.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryListProject.list.column.projectId.label': 'Project Id',
    'intent.projectCatalogue.qryListProject.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryListProject.list.column.name.label': 'Name',
    'intent.projectCatalogue.qryListProject.list.column.address.label': 'Address',
    'intent.projectCatalogue.qryListProject.list.column.status.label': 'Status',
    'intent.projectCatalogue.qryListProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.qryListProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.qryListProject.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdDeleteProject.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.action.cmdDeleteProject': 'Excluir Obra',
    'section.projectCatalogue.recordForm.title': 'Criar ou corrigir obra',
    'organism.projectCatalogue.cmdCreateProject.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.action.cmdCreateProject': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdCreateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdCreateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdCreateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdCreateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdUpdateProject.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.action.cmdUpdateProject': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdUpdateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdUpdateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdUpdateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdUpdateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.qryClientPicker.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.projectCatalogue.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.projectCatalogue.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'action.cmdCreateProject.success': 'Criar Obra: OK',
    'action.cmdCreateProject.error': 'Criar Obra: falhou',
    'action.cmdUpdateProject.success': 'Atualizar Obra: OK',
    'action.cmdUpdateProject.error': 'Atualizar Obra: falhou',
    'action.cmdDeleteProject.success': 'Excluir Obra: OK',
    'action.cmdDeleteProject.error': 'Excluir Obra: falhou',
    'section.projectCatalogue.projectWorkbench.title': 'Obras',
    'section.projectCatalogue.projectCreation.title': 'Nova obra',
    'section.projectCatalogue.projectWorkspace.title': 'Localização e manutenção de obras',
};
const message_en = {
    'section.projectCatalogue.recordList.title': 'Localizar obra',
    'organism.projectCatalogue.qryListProject.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryListProject.list.column.projectId.label': 'Project Id',
    'intent.projectCatalogue.qryListProject.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryListProject.list.column.name.label': 'Name',
    'intent.projectCatalogue.qryListProject.list.column.address.label': 'Address',
    'intent.projectCatalogue.qryListProject.list.column.status.label': 'Status',
    'intent.projectCatalogue.qryListProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.qryListProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.qryListProject.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdDeleteProject.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.action.cmdDeleteProject': 'Excluir Obra',
    'section.projectCatalogue.recordForm.title': 'Criar ou corrigir obra',
    'organism.projectCatalogue.cmdCreateProject.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.action.cmdCreateProject': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdCreateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdCreateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdCreateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdCreateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdUpdateProject.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.action.cmdUpdateProject': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdUpdateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdUpdateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdUpdateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdUpdateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.qryClientPicker.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.projectCatalogue.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.projectCatalogue.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'action.cmdCreateProject.success': 'Criar Obra: OK',
    'action.cmdCreateProject.error': 'Criar Obra: falhou',
    'action.cmdUpdateProject.success': 'Atualizar Obra: OK',
    'action.cmdUpdateProject.error': 'Atualizar Obra: falhou',
    'action.cmdDeleteProject.success': 'Excluir Obra: OK',
    'action.cmdDeleteProject.error': 'Excluir Obra: falhou',
    'section.projectCatalogue.projectWorkbench.title': 'Obras',
    'section.projectCatalogue.projectCreation.title': 'Nova obra',
    'section.projectCatalogue.projectWorkspace.title': 'Localização e manutenção de obras',
};
const message_es = {
    'section.projectCatalogue.recordList.title': 'Localizar obra',
    'organism.projectCatalogue.qryListProject.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.title': 'Listar Obra',
    'intent.projectCatalogue.qryListProject.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryListProject.list.column.projectId.label': 'Project Id',
    'intent.projectCatalogue.qryListProject.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryListProject.list.column.name.label': 'Name',
    'intent.projectCatalogue.qryListProject.list.column.address.label': 'Address',
    'intent.projectCatalogue.qryListProject.list.column.status.label': 'Status',
    'intent.projectCatalogue.qryListProject.list.column.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.qryListProject.list.column.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.qryListProject.list.column.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdDeleteProject.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.title': 'Excluir Obra',
    'intent.projectCatalogue.cmdDeleteProject.form.action.cmdDeleteProject': 'Excluir Obra',
    'section.projectCatalogue.recordForm.title': 'Criar ou corrigir obra',
    'organism.projectCatalogue.cmdCreateProject.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.title': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.action.cmdCreateProject': 'Criar Obra',
    'intent.projectCatalogue.cmdCreateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdCreateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdCreateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdCreateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdCreateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdCreateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.cmdUpdateProject.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.title': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.action.cmdUpdateProject': 'Atualizar Obra',
    'intent.projectCatalogue.cmdUpdateProject.form.field.clientId.label': 'Client Id',
    'intent.projectCatalogue.cmdUpdateProject.form.field.name.label': 'Name',
    'intent.projectCatalogue.cmdUpdateProject.form.field.address.label': 'Address',
    'intent.projectCatalogue.cmdUpdateProject.form.field.status.label': 'Status',
    'intent.projectCatalogue.cmdUpdateProject.form.field.authorizedBudget.label': 'Authorized Budget',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedStartDate.label': 'Planned Start Date',
    'intent.projectCatalogue.cmdUpdateProject.form.field.plannedEndDate.label': 'Planned End Date',
    'organism.projectCatalogue.qryClientPicker.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.title': 'Listar Cliente',
    'intent.projectCatalogue.qryClientPicker.list.empty': 'Nenhum registro encontrado',
    'intent.projectCatalogue.qryClientPicker.list.column.clientId.label': 'Client Id',
    'intent.projectCatalogue.qryClientPicker.list.column.clientName.label': 'Client Name',
    'intent.projectCatalogue.qryClientPicker.list.column.contactEmail.label': 'Contact Email',
    'intent.projectCatalogue.qryClientPicker.list.column.contactPhone.label': 'Contact Phone',
    'action.cmdCreateProject.success': 'Criar Obra: OK',
    'action.cmdCreateProject.error': 'Criar Obra: falhou',
    'action.cmdUpdateProject.success': 'Atualizar Obra: OK',
    'action.cmdUpdateProject.error': 'Atualizar Obra: falhou',
    'action.cmdDeleteProject.success': 'Excluir Obra: OK',
    'action.cmdDeleteProject.error': 'Excluir Obra: falhou',
    'section.projectCatalogue.projectWorkbench.title': 'Obras',
    'section.projectCatalogue.projectCreation.title': 'Nova obra',
    'section.projectCatalogue.projectWorkspace.title': 'Localização e manutenção de obras',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.projectCatalogue.status',
    'ui.projectCatalogue.action.qryListProject.status',
    'ui.projectCatalogue.data.qryListProject',
    'ui.projectCatalogue.action.cmdCreateProject.status',
    'ui.projectCatalogue.input.cmdCreateProject.clientId',
    'ui.projectCatalogue.input.cmdCreateProject.name',
    'ui.projectCatalogue.input.cmdCreateProject.address',
    'ui.projectCatalogue.input.cmdCreateProject.status',
    'ui.projectCatalogue.input.cmdCreateProject.authorizedBudget',
    'ui.projectCatalogue.input.cmdCreateProject.plannedStartDate',
    'ui.projectCatalogue.input.cmdCreateProject.plannedEndDate',
    'ui.projectCatalogue.output.cmdCreateProject',
    'ui.projectCatalogue.action.cmdCreateProject.error',
    'ui.projectCatalogue.action.cmdUpdateProject.status',
    'ui.projectCatalogue.input.cmdUpdateProject.projectId',
    'ui.projectCatalogue.input.cmdUpdateProject.clientId',
    'ui.projectCatalogue.input.cmdUpdateProject.name',
    'ui.projectCatalogue.input.cmdUpdateProject.address',
    'ui.projectCatalogue.input.cmdUpdateProject.status',
    'ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget',
    'ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate',
    'ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate',
    'ui.projectCatalogue.output.cmdUpdateProject',
    'ui.projectCatalogue.action.cmdUpdateProject.error',
    'ui.projectCatalogue.action.cmdDeleteProject.status',
    'ui.projectCatalogue.input.cmdDeleteProject.projectId',
    'ui.projectCatalogue.output.cmdDeleteProject',
    'ui.projectCatalogue.action.cmdDeleteProject.error',
    'ui.projectCatalogue.action.qryClientPicker.status',
    'ui.projectCatalogue.data.qryClientPicker',
];
export class BuildFlowFsmProjectCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListProjectState — actionStatus, values: idle|loading|success|error */
        this.qryListProjectState = 'idle';
        /** state qryListProjectData — queryResult, outputShape: array */
        this.qryListProjectData = [];
        /** state cmdCreateProjectState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateProjectState = 'idle';
        /** state cmdCreateProjectClientId — input */
        this.cmdCreateProjectClientId = '';
        /** state cmdCreateProjectName — input */
        this.cmdCreateProjectName = '';
        /** state cmdCreateProjectAddress — input */
        this.cmdCreateProjectAddress = '';
        /** state cmdCreateProjectStatus — input */
        this.cmdCreateProjectStatus = '';
        /** state cmdCreateProjectAuthorizedBudget — input */
        this.cmdCreateProjectAuthorizedBudget = '';
        /** state cmdCreateProjectPlannedStartDate — input */
        this.cmdCreateProjectPlannedStartDate = '';
        /** state cmdCreateProjectPlannedEndDate — input */
        this.cmdCreateProjectPlannedEndDate = '';
        /** state cmdCreateProjectOutput — commandOutput */
        this.cmdCreateProjectOutput = null;
        /** state cmdCreateProjectError — actionError */
        this.cmdCreateProjectError = '';
        /** state cmdUpdateProjectState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateProjectState = 'idle';
        /** state cmdUpdateProjectProjectId — input */
        this.cmdUpdateProjectProjectId = '';
        /** state cmdUpdateProjectClientId — input */
        this.cmdUpdateProjectClientId = '';
        /** state cmdUpdateProjectName — input */
        this.cmdUpdateProjectName = '';
        /** state cmdUpdateProjectAddress — input */
        this.cmdUpdateProjectAddress = '';
        /** state cmdUpdateProjectStatus — input */
        this.cmdUpdateProjectStatus = '';
        /** state cmdUpdateProjectAuthorizedBudget — input */
        this.cmdUpdateProjectAuthorizedBudget = '';
        /** state cmdUpdateProjectPlannedStartDate — input */
        this.cmdUpdateProjectPlannedStartDate = '';
        /** state cmdUpdateProjectPlannedEndDate — input */
        this.cmdUpdateProjectPlannedEndDate = '';
        /** state cmdUpdateProjectOutput — commandOutput */
        this.cmdUpdateProjectOutput = null;
        /** state cmdUpdateProjectError — actionError */
        this.cmdUpdateProjectError = '';
        /** state cmdDeleteProjectState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteProjectState = 'idle';
        /** state cmdDeleteProjectProjectId — input */
        this.cmdDeleteProjectProjectId = '';
        /** state cmdDeleteProjectOutput — commandOutput */
        this.cmdDeleteProjectOutput = null;
        /** state cmdDeleteProjectError — actionError */
        this.cmdDeleteProjectError = '';
        /** state qryClientPickerState — actionStatus, values: idle|loading|success|error */
        this.qryClientPickerState = 'idle';
        /** state qryClientPickerData — queryResult, outputShape: array */
        this.qryClientPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.projectCatalogue.status', '');
        this.initStateValue('ui.projectCatalogue.action.qryListProject.status', 'idle');
        this.initStateValue('ui.projectCatalogue.data.qryListProject', []);
        this.initStateValue('ui.projectCatalogue.action.cmdCreateProject.status', 'idle');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.clientId', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.name', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.address', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.status', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.authorizedBudget', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.plannedStartDate', '');
        this.initStateValue('ui.projectCatalogue.input.cmdCreateProject.plannedEndDate', '');
        this.initStateValue('ui.projectCatalogue.output.cmdCreateProject', null);
        this.initStateValue('ui.projectCatalogue.action.cmdCreateProject.error', '');
        this.initStateValue('ui.projectCatalogue.action.cmdUpdateProject.status', 'idle');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.projectId', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.clientId', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.name', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.address', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.status', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate', '');
        this.initStateValue('ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate', '');
        this.initStateValue('ui.projectCatalogue.output.cmdUpdateProject', null);
        this.initStateValue('ui.projectCatalogue.action.cmdUpdateProject.error', '');
        this.initStateValue('ui.projectCatalogue.action.cmdDeleteProject.status', 'idle');
        this.initStateValue('ui.projectCatalogue.input.cmdDeleteProject.projectId', '');
        this.initStateValue('ui.projectCatalogue.output.cmdDeleteProject', null);
        this.initStateValue('ui.projectCatalogue.action.cmdDeleteProject.error', '');
        this.initStateValue('ui.projectCatalogue.action.qryClientPicker.status', 'idle');
        this.initStateValue('ui.projectCatalogue.data.qryClientPicker', []);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListProject();
        void this.loadQryClientPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.projectCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.projectCatalogue.action.qryListProject.status':
                this.qryListProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.data.qryListProject':
                this.qryListProjectData = value ?? [];
                break;
            case 'ui.projectCatalogue.action.cmdCreateProject.status':
                this.cmdCreateProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.clientId':
                this.cmdCreateProjectClientId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.name':
                this.cmdCreateProjectName = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.address':
                this.cmdCreateProjectAddress = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.status':
                this.cmdCreateProjectStatus = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.authorizedBudget':
                this.cmdCreateProjectAuthorizedBudget = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.plannedStartDate':
                this.cmdCreateProjectPlannedStartDate = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.plannedEndDate':
                this.cmdCreateProjectPlannedEndDate = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdCreateProject':
                this.cmdCreateProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdCreateProject.error':
                this.cmdCreateProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.cmdUpdateProject.status':
                this.cmdUpdateProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.projectId':
                this.cmdUpdateProjectProjectId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.clientId':
                this.cmdUpdateProjectClientId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.name':
                this.cmdUpdateProjectName = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.address':
                this.cmdUpdateProjectAddress = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.status':
                this.cmdUpdateProjectStatus = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget':
                this.cmdUpdateProjectAuthorizedBudget = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate':
                this.cmdUpdateProjectPlannedStartDate = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate':
                this.cmdUpdateProjectPlannedEndDate = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdUpdateProject':
                this.cmdUpdateProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdUpdateProject.error':
                this.cmdUpdateProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.cmdDeleteProject.status':
                this.cmdDeleteProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdDeleteProject.projectId':
                this.cmdDeleteProjectProjectId = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdDeleteProject':
                this.cmdDeleteProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdDeleteProject.error':
                this.cmdDeleteProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.qryClientPicker.status':
                this.qryClientPickerState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.data.qryClientPicker':
                this.qryClientPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.projectCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.projectCatalogue.action.qryListProject.status':
                this.qryListProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.data.qryListProject':
                this.qryListProjectData = value ?? [];
                break;
            case 'ui.projectCatalogue.action.cmdCreateProject.status':
                this.cmdCreateProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.clientId':
                this.cmdCreateProjectClientId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.name':
                this.cmdCreateProjectName = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.address':
                this.cmdCreateProjectAddress = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.status':
                this.cmdCreateProjectStatus = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.authorizedBudget':
                this.cmdCreateProjectAuthorizedBudget = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.plannedStartDate':
                this.cmdCreateProjectPlannedStartDate = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdCreateProject.plannedEndDate':
                this.cmdCreateProjectPlannedEndDate = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdCreateProject':
                this.cmdCreateProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdCreateProject.error':
                this.cmdCreateProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.cmdUpdateProject.status':
                this.cmdUpdateProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.projectId':
                this.cmdUpdateProjectProjectId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.clientId':
                this.cmdUpdateProjectClientId = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.name':
                this.cmdUpdateProjectName = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.address':
                this.cmdUpdateProjectAddress = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.status':
                this.cmdUpdateProjectStatus = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget':
                this.cmdUpdateProjectAuthorizedBudget = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate':
                this.cmdUpdateProjectPlannedStartDate = value ?? '';
                break;
            case 'ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate':
                this.cmdUpdateProjectPlannedEndDate = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdUpdateProject':
                this.cmdUpdateProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdUpdateProject.error':
                this.cmdUpdateProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.cmdDeleteProject.status':
                this.cmdDeleteProjectState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.input.cmdDeleteProject.projectId':
                this.cmdDeleteProjectProjectId = value ?? '';
                break;
            case 'ui.projectCatalogue.output.cmdDeleteProject':
                this.cmdDeleteProjectOutput = value ?? null;
                break;
            case 'ui.projectCatalogue.action.cmdDeleteProject.error':
                this.cmdDeleteProjectError = value ?? '';
                break;
            case 'ui.projectCatalogue.action.qryClientPicker.status':
                this.qryClientPickerState = value ?? 'idle';
                break;
            case 'ui.projectCatalogue.data.qryClientPicker':
                this.qryClientPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListProject (query) — route buildFlowFsm.projectCatalogue.qryListProject; inputs: (none); writes ui.projectCatalogue.data.qryListProject; status ui.projectCatalogue.action.qryListProject.status */
    async loadQryListProject() {
        this.qryListProjectState = 'loading';
        setState('ui.projectCatalogue.action.qryListProject.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListProjectRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListProjectData = data;
            setState('ui.projectCatalogue.data.qryListProject', data);
            this.qryListProjectState = 'success';
            setState('ui.projectCatalogue.action.qryListProject.status', 'success');
        }
        else {
            this.qryListProjectState = 'error';
            setState('ui.projectCatalogue.action.qryListProject.status', 'error');
            if (response.error) {
                console.error('qryListProject failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListProject — bind UI events here */
    handleQryListProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListProject();
    }
    /** action cmdCreateProject (command) — route buildFlowFsm.projectCatalogue.cmdCreateProject; inputs: clientId, name, address, status, authorizedBudget, plannedStartDate, plannedEndDate; writes ui.projectCatalogue.output.cmdCreateProject; status ui.projectCatalogue.action.cmdCreateProject.status; feedback keys action.cmdCreateProject.success / action.cmdCreateProject.error */
    async cmdCreateProject() {
        this.cmdCreateProjectState = 'loading';
        setState('ui.projectCatalogue.action.cmdCreateProject.status', 'loading');
        this.cmdCreateProjectError = '';
        setState('ui.projectCatalogue.action.cmdCreateProject.error', '');
        const authorizedBudgetNum = Number(this.cmdCreateProjectAuthorizedBudget);
        const params = {
            clientId: this.cmdCreateProjectClientId,
            name: this.cmdCreateProjectName,
            address: this.cmdCreateProjectAddress,
            status: this.cmdCreateProjectStatus,
            authorizedBudget: Number.isNaN(authorizedBudgetNum) ? 0 : authorizedBudgetNum,
            plannedStartDate: this.cmdCreateProjectPlannedStartDate,
            plannedEndDate: this.cmdCreateProjectPlannedEndDate,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateProjectRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateProject.error');
            this.cmdCreateProjectError = errMsg;
            setState('ui.projectCatalogue.action.cmdCreateProject.error', errMsg);
            this.cmdCreateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdCreateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateProjectOutput = data;
        setState('ui.projectCatalogue.output.cmdCreateProject', data);
        try {
            await this.loadQryListProject();
            if (this.qryListProjectState === 'error') {
                this.cmdCreateProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdCreateProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateProject refresh failed', refreshError);
            this.cmdCreateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdCreateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryClientPicker();
            if (this.qryClientPickerState === 'error') {
                this.cmdCreateProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdCreateProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateProject refresh failed', refreshError);
            this.cmdCreateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdCreateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateProjectClientId = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.clientId', '');
        this.cmdCreateProjectName = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.name', '');
        this.cmdCreateProjectAddress = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.address', '');
        this.cmdCreateProjectStatus = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.status', '');
        this.cmdCreateProjectAuthorizedBudget = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.authorizedBudget', '');
        this.cmdCreateProjectPlannedStartDate = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.plannedStartDate', '');
        this.cmdCreateProjectPlannedEndDate = '';
        setState('ui.projectCatalogue.input.cmdCreateProject.plannedEndDate', '');
        this.cmdCreateProjectState = 'success';
        setState('ui.projectCatalogue.action.cmdCreateProject.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateProject — bind UI events here */
    handleCmdCreateProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateProject();
        });
    }
    /** action cmdUpdateProject (command) — route buildFlowFsm.projectCatalogue.cmdUpdateProject; inputs: projectId, clientId, name, address, status, authorizedBudget, plannedStartDate, plannedEndDate; writes ui.projectCatalogue.output.cmdUpdateProject; status ui.projectCatalogue.action.cmdUpdateProject.status; feedback keys action.cmdUpdateProject.success / action.cmdUpdateProject.error */
    async cmdUpdateProject() {
        if (!this.cmdUpdateProjectProjectId) {
            this.cmdUpdateProjectState = 'idle';
            setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateProjectState = 'loading';
        setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'loading');
        this.cmdUpdateProjectError = '';
        setState('ui.projectCatalogue.action.cmdUpdateProject.error', '');
        const authorizedBudgetNum = Number(this.cmdUpdateProjectAuthorizedBudget);
        const params = {
            projectId: this.cmdUpdateProjectProjectId,
            clientId: this.cmdUpdateProjectClientId,
            name: this.cmdUpdateProjectName,
            address: this.cmdUpdateProjectAddress,
            status: this.cmdUpdateProjectStatus,
            authorizedBudget: Number.isNaN(authorizedBudgetNum) ? 0 : authorizedBudgetNum,
            plannedStartDate: this.cmdUpdateProjectPlannedStartDate,
            plannedEndDate: this.cmdUpdateProjectPlannedEndDate,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateProjectRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateProject.error');
            this.cmdUpdateProjectError = errMsg;
            setState('ui.projectCatalogue.action.cmdUpdateProject.error', errMsg);
            this.cmdUpdateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateProjectOutput = data;
        setState('ui.projectCatalogue.output.cmdUpdateProject', data);
        try {
            await this.loadQryListProject();
            if (this.qryListProjectState === 'error') {
                this.cmdUpdateProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateProject refresh failed', refreshError);
            this.cmdUpdateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryClientPicker();
            if (this.qryClientPickerState === 'error') {
                this.cmdUpdateProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateProject refresh failed', refreshError);
            this.cmdUpdateProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateProjectProjectId = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.projectId', '');
        this.cmdUpdateProjectClientId = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.clientId', '');
        this.cmdUpdateProjectName = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.name', '');
        this.cmdUpdateProjectAddress = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.address', '');
        this.cmdUpdateProjectStatus = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.status', '');
        this.cmdUpdateProjectAuthorizedBudget = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget', '');
        this.cmdUpdateProjectPlannedStartDate = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate', '');
        this.cmdUpdateProjectPlannedEndDate = '';
        setState('ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate', '');
        this.cmdUpdateProjectState = 'success';
        setState('ui.projectCatalogue.action.cmdUpdateProject.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateProject — bind UI events here */
    handleCmdUpdateProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateProject();
        });
    }
    /** action cmdDeleteProject (command) — route buildFlowFsm.projectCatalogue.cmdDeleteProject; inputs: projectId; writes ui.projectCatalogue.output.cmdDeleteProject; status ui.projectCatalogue.action.cmdDeleteProject.status; feedback keys action.cmdDeleteProject.success / action.cmdDeleteProject.error */
    async cmdDeleteProject() {
        if (!this.cmdDeleteProjectProjectId) {
            this.cmdDeleteProjectState = 'idle';
            setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteProjectState = 'loading';
        setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'loading');
        this.cmdDeleteProjectError = '';
        setState('ui.projectCatalogue.action.cmdDeleteProject.error', '');
        const params = {
            projectId: this.cmdDeleteProjectProjectId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteProjectRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteProject.error');
            this.cmdDeleteProjectError = errMsg;
            setState('ui.projectCatalogue.action.cmdDeleteProject.error', errMsg);
            this.cmdDeleteProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteProjectOutput = data;
        setState('ui.projectCatalogue.output.cmdDeleteProject', data);
        try {
            await this.loadQryListProject();
            if (this.qryListProjectState === 'error') {
                this.cmdDeleteProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteProject refresh failed', refreshError);
            this.cmdDeleteProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryClientPicker();
            if (this.qryClientPickerState === 'error') {
                this.cmdDeleteProjectState = 'error';
                setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteProject refresh failed', refreshError);
            this.cmdDeleteProjectState = 'error';
            setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteProjectProjectId = '';
        setState('ui.projectCatalogue.input.cmdDeleteProject.projectId', '');
        this.cmdDeleteProjectState = 'success';
        setState('ui.projectCatalogue.action.cmdDeleteProject.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteProject — bind UI events here */
    handleCmdDeleteProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteProject();
        });
    }
    /** action qryClientPicker (query) — route buildFlowFsm.projectCatalogue.qryClientPicker; inputs: (none); writes ui.projectCatalogue.data.qryClientPicker; status ui.projectCatalogue.action.qryClientPicker.status */
    async loadQryClientPicker() {
        this.qryClientPickerState = 'loading';
        setState('ui.projectCatalogue.action.qryClientPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryClientPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryClientPickerData = data;
            setState('ui.projectCatalogue.data.qryClientPicker', data);
            this.qryClientPickerState = 'success';
            setState('ui.projectCatalogue.action.qryClientPicker.status', 'success');
        }
        else {
            this.qryClientPickerState = 'error';
            setState('ui.projectCatalogue.action.qryClientPicker.status', 'error');
            if (response.error) {
                console.error('qryClientPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryClientPicker — bind UI events here */
    handleQryClientPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryClientPicker();
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.clientId */
    setCmdCreateProjectClientId(value) {
        this.cmdCreateProjectClientId = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectClientId — bind UI events here */
    handleCmdCreateProjectClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectClientId(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.name */
    setCmdCreateProjectName(value) {
        this.cmdCreateProjectName = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.name', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectName — bind UI events here */
    handleCmdCreateProjectNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectName(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.address */
    setCmdCreateProjectAddress(value) {
        this.cmdCreateProjectAddress = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.address', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectAddress — bind UI events here */
    handleCmdCreateProjectAddressChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectAddress(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.status */
    setCmdCreateProjectStatus(value) {
        this.cmdCreateProjectStatus = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectStatus — bind UI events here */
    handleCmdCreateProjectStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectStatus(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.authorizedBudget */
    setCmdCreateProjectAuthorizedBudget(value) {
        this.cmdCreateProjectAuthorizedBudget = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.authorizedBudget', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectAuthorizedBudget — bind UI events here */
    handleCmdCreateProjectAuthorizedBudgetChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectAuthorizedBudget(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.plannedStartDate */
    setCmdCreateProjectPlannedStartDate(value) {
        this.cmdCreateProjectPlannedStartDate = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.plannedStartDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectPlannedStartDate — bind UI events here */
    handleCmdCreateProjectPlannedStartDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectPlannedStartDate(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdCreateProject.plannedEndDate */
    setCmdCreateProjectPlannedEndDate(value) {
        this.cmdCreateProjectPlannedEndDate = value;
        setState('ui.projectCatalogue.input.cmdCreateProject.plannedEndDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateProjectPlannedEndDate — bind UI events here */
    handleCmdCreateProjectPlannedEndDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateProjectPlannedEndDate(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.projectId */
    setCmdUpdateProjectProjectId(value) {
        this.cmdUpdateProjectProjectId = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.projectId', value);
        const collection = getState('ui.projectCatalogue.data.qryListProject') ?? this.qryListProjectData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.projectId) === String(value));
            if (item) {
                this.cmdUpdateProjectClientId = item.clientId;
                setState('ui.projectCatalogue.input.cmdUpdateProject.clientId', item.clientId);
                this.cmdUpdateProjectName = item.name;
                setState('ui.projectCatalogue.input.cmdUpdateProject.name', item.name);
                this.cmdUpdateProjectAddress = item.address;
                setState('ui.projectCatalogue.input.cmdUpdateProject.address', item.address);
                this.cmdUpdateProjectStatus = item.status;
                setState('ui.projectCatalogue.input.cmdUpdateProject.status', item.status);
                this.cmdUpdateProjectAuthorizedBudget = String(item.authorizedBudget);
                setState('ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget', String(item.authorizedBudget));
                this.cmdUpdateProjectPlannedStartDate = item.plannedStartDate;
                setState('ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate', item.plannedStartDate);
                this.cmdUpdateProjectPlannedEndDate = item.plannedEndDate;
                setState('ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate', item.plannedEndDate);
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectProjectId — bind UI events here */
    handleCmdUpdateProjectProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectProjectId(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.clientId */
    setCmdUpdateProjectClientId(value) {
        this.cmdUpdateProjectClientId = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectClientId — bind UI events here */
    handleCmdUpdateProjectClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectClientId(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.name */
    setCmdUpdateProjectName(value) {
        this.cmdUpdateProjectName = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.name', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectName — bind UI events here */
    handleCmdUpdateProjectNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectName(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.address */
    setCmdUpdateProjectAddress(value) {
        this.cmdUpdateProjectAddress = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.address', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectAddress — bind UI events here */
    handleCmdUpdateProjectAddressChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectAddress(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.status */
    setCmdUpdateProjectStatus(value) {
        this.cmdUpdateProjectStatus = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectStatus — bind UI events here */
    handleCmdUpdateProjectStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectStatus(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget */
    setCmdUpdateProjectAuthorizedBudget(value) {
        this.cmdUpdateProjectAuthorizedBudget = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.authorizedBudget', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectAuthorizedBudget — bind UI events here */
    handleCmdUpdateProjectAuthorizedBudgetChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectAuthorizedBudget(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate */
    setCmdUpdateProjectPlannedStartDate(value) {
        this.cmdUpdateProjectPlannedStartDate = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.plannedStartDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectPlannedStartDate — bind UI events here */
    handleCmdUpdateProjectPlannedStartDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectPlannedStartDate(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate */
    setCmdUpdateProjectPlannedEndDate(value) {
        this.cmdUpdateProjectPlannedEndDate = value;
        setState('ui.projectCatalogue.input.cmdUpdateProject.plannedEndDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateProjectPlannedEndDate — bind UI events here */
    handleCmdUpdateProjectPlannedEndDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateProjectPlannedEndDate(value);
    }
    /** setter for state ui.projectCatalogue.input.cmdDeleteProject.projectId */
    setCmdDeleteProjectProjectId(value) {
        this.cmdDeleteProjectProjectId = value;
        setState('ui.projectCatalogue.input.cmdDeleteProject.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteProjectProjectId — bind UI events here */
    handleCmdDeleteProjectProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteProjectProjectId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "qryListProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "qryListProjectData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectClientId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectName", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectAddress", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectAuthorizedBudget", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectPlannedStartDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectPlannedEndDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectOutput", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdCreateProjectError", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectClientId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectName", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectAddress", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectAuthorizedBudget", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectPlannedStartDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectPlannedEndDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectOutput", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdUpdateProjectError", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdDeleteProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdDeleteProjectProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdDeleteProjectOutput", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "cmdDeleteProjectError", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "qryClientPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectCatalogueBase.prototype, "qryClientPickerData", void 0);
