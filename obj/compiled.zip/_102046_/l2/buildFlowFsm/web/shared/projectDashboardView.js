/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/projectDashboardView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryProjectDashboardViewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/projectDashboardView.js';
/// **collab_i18n_start**
const message_pt = {
    'section.projectDashboardView.overview.title': 'Visão geral do portfólio',
    'organism.projectDashboardView.qryProjectDashboardView.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.empty': 'Nenhum registro encontrado',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjects.label': 'Active Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjectCount.label': 'Active Project Count',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalBudget.label': 'Total Budget',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalActualCost.label': 'Total Actual Cost',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.budgetVariance.label': 'Budget Variance',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.costAttentionProjects.label': 'Cost Attention Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.upcomingTasks.label': 'Upcoming Tasks',
};
const message_pt_br = {
    'section.projectDashboardView.overview.title': 'Visão geral do portfólio',
    'organism.projectDashboardView.qryProjectDashboardView.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.empty': 'Nenhum registro encontrado',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjects.label': 'Active Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjectCount.label': 'Active Project Count',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalBudget.label': 'Total Budget',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalActualCost.label': 'Total Actual Cost',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.budgetVariance.label': 'Budget Variance',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.costAttentionProjects.label': 'Cost Attention Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.upcomingTasks.label': 'Upcoming Tasks',
};
const message_en = {
    'section.projectDashboardView.overview.title': 'Visão geral do portfólio',
    'organism.projectDashboardView.qryProjectDashboardView.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.empty': 'Nenhum registro encontrado',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjects.label': 'Active Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjectCount.label': 'Active Project Count',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalBudget.label': 'Total Budget',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalActualCost.label': 'Total Actual Cost',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.budgetVariance.label': 'Budget Variance',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.costAttentionProjects.label': 'Cost Attention Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.upcomingTasks.label': 'Upcoming Tasks',
};
const message_es = {
    'section.projectDashboardView.overview.title': 'Visão geral do portfólio',
    'organism.projectDashboardView.qryProjectDashboardView.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.title': 'Consultar o painel de obras',
    'intent.projectDashboardView.qryProjectDashboardView.list.empty': 'Nenhum registro encontrado',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjects.label': 'Active Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.activeProjectCount.label': 'Active Project Count',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalBudget.label': 'Total Budget',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.totalActualCost.label': 'Total Actual Cost',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.budgetVariance.label': 'Budget Variance',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.costAttentionProjects.label': 'Cost Attention Projects',
    'intent.projectDashboardView.qryProjectDashboardView.list.column.upcomingTasks.label': 'Upcoming Tasks',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.projectDashboardView.status',
    'ui.projectDashboardView.action.qryProjectDashboardView.status',
    'ui.projectDashboardView.data.qryProjectDashboardView',
];
export class BuildFlowFsmProjectDashboardViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryProjectDashboardViewState — actionStatus, values: idle|loading|success|error */
        this.qryProjectDashboardViewState = 'idle';
        /** state qryProjectDashboardViewData — queryResult, outputShape: object */
        this.qryProjectDashboardViewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.projectDashboardView.status', '');
        this.initStateValue('ui.projectDashboardView.action.qryProjectDashboardView.status', 'idle');
        this.initStateValue('ui.projectDashboardView.data.qryProjectDashboardView', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryProjectDashboardView();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.projectDashboardView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectDashboardView.action.qryProjectDashboardView.status':
                this.qryProjectDashboardViewState = value ?? 'idle';
                break;
            case 'ui.projectDashboardView.data.qryProjectDashboardView':
                this.qryProjectDashboardViewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.projectDashboardView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectDashboardView.action.qryProjectDashboardView.status':
                this.qryProjectDashboardViewState = value ?? 'idle';
                break;
            case 'ui.projectDashboardView.data.qryProjectDashboardView':
                this.qryProjectDashboardViewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryProjectDashboardView (query) — route buildFlowFsm.projectDashboardView.qryProjectDashboardView; inputs: (none); writes ui.projectDashboardView.data.qryProjectDashboardView; status ui.projectDashboardView.action.qryProjectDashboardView.status */
    async loadQryProjectDashboardView() {
        this.qryProjectDashboardViewState = 'loading';
        setState('ui.projectDashboardView.action.qryProjectDashboardView.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryProjectDashboardViewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryProjectDashboardViewData = data;
            setState('ui.projectDashboardView.data.qryProjectDashboardView', data);
            this.qryProjectDashboardViewState = 'success';
            setState('ui.projectDashboardView.action.qryProjectDashboardView.status', 'success');
        }
        else {
            this.qryProjectDashboardViewState = 'error';
            setState('ui.projectDashboardView.action.qryProjectDashboardView.status', 'error');
            if (response.error) {
                console.error('qryProjectDashboardView failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryProjectDashboardView — bind UI events here */
    handleQryProjectDashboardViewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryProjectDashboardView();
    }
}
__decorate([
    property()
], BuildFlowFsmProjectDashboardViewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDashboardViewBase.prototype, "qryProjectDashboardViewState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDashboardViewBase.prototype, "qryProjectDashboardViewData", void 0);
