/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/projectExecutionOverviewView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryProjectExecutionOverviewViewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/projectExecutionOverviewView.js';
/// **collab_i18n_start**
const message_pt = {
    'section.projectExecutionOverviewView.overview.title': 'Visão consolidada da execução',
    'organism.projectExecutionOverviewView.qryProjectExecutionOverviewView.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.empty': 'Nenhum registro encontrado',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectId.label': 'Project Id',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectName.label': 'Project Name',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectStatus.label': 'Project Status',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.taskSummary.label': 'Task Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualCost.label': 'Actual Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.budgetAmount.label': 'Budget Amount',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.costVariance.label': 'Cost Variance',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.calculatedAt.label': 'Calculated At',
};
const message_pt_br = {
    'section.projectExecutionOverviewView.overview.title': 'Visão consolidada da execução',
    'organism.projectExecutionOverviewView.qryProjectExecutionOverviewView.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.empty': 'Nenhum registro encontrado',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectId.label': 'Project Id',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectName.label': 'Project Name',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectStatus.label': 'Project Status',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.taskSummary.label': 'Task Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualCost.label': 'Actual Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.budgetAmount.label': 'Budget Amount',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.costVariance.label': 'Cost Variance',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.calculatedAt.label': 'Calculated At',
};
const message_en = {
    'section.projectExecutionOverviewView.overview.title': 'Visão consolidada da execução',
    'organism.projectExecutionOverviewView.qryProjectExecutionOverviewView.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.empty': 'Nenhum registro encontrado',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectId.label': 'Project Id',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectName.label': 'Project Name',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectStatus.label': 'Project Status',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.taskSummary.label': 'Task Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualCost.label': 'Actual Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.budgetAmount.label': 'Budget Amount',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.costVariance.label': 'Cost Variance',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.calculatedAt.label': 'Calculated At',
};
const message_es = {
    'section.projectExecutionOverviewView.overview.title': 'Visão consolidada da execução',
    'organism.projectExecutionOverviewView.qryProjectExecutionOverviewView.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.title': 'Analisar a execução da obra',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.empty': 'Nenhum registro encontrado',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectId.label': 'Project Id',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectName.label': 'Project Name',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.projectStatus.label': 'Project Status',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.workTaskIds.label': 'Work Task Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.taskSummary.label': 'Task Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.upcomingCommitments.label': 'Upcoming Commitments',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.timeLogIds.label': 'Time Log Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.totalLoggedHours.label': 'Total Logged Hours',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageIds.label': 'Material Usage Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.materialUsageSummary.label': 'Material Usage Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualLaborCost.label': 'Actual Labor Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualMaterialCost.label': 'Actual Material Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.actualCost.label': 'Actual Cost',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.budgetAmount.label': 'Budget Amount',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.costVariance.label': 'Cost Variance',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderIds.label': 'Change Order Ids',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.changeOrderImpactSummary.label': 'Change Order Impact Summary',
    'intent.projectExecutionOverviewView.qryProjectExecutionOverviewView.list.column.calculatedAt.label': 'Calculated At',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.projectExecutionOverviewView.status',
    'ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status',
    'ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId',
    'ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView',
];
export class BuildFlowFsmProjectExecutionOverviewViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryProjectExecutionOverviewViewState — actionStatus, values: idle|loading|success|error */
        this.qryProjectExecutionOverviewViewState = 'idle';
        /** state qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId — input */
        this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId = '';
        /** state qryProjectExecutionOverviewViewData — queryResult, outputShape: object */
        this.qryProjectExecutionOverviewViewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.projectExecutionOverviewView.status', '');
        this.initStateValue('ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status', 'idle');
        this.initStateValue('ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId', '');
        this.initStateValue('ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.projectExecutionOverviewView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status':
                this.qryProjectExecutionOverviewViewState = value ?? 'idle';
                break;
            case 'ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId':
                this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId = value ?? '';
                break;
            case 'ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView':
                this.qryProjectExecutionOverviewViewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.projectExecutionOverviewView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status':
                this.qryProjectExecutionOverviewViewState = value ?? 'idle';
                break;
            case 'ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId':
                this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId = value ?? '';
                break;
            case 'ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView':
                this.qryProjectExecutionOverviewViewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryProjectExecutionOverviewView (query) — route buildFlowFsm.projectExecutionOverviewView.qryProjectExecutionOverviewView; inputs: projectExecutionOverviewProjectId; writes ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView; status ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status */
    async loadQryProjectExecutionOverviewView() {
        if (!this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId) {
            this.qryProjectExecutionOverviewViewState = 'idle';
            setState('ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryProjectExecutionOverviewViewState = 'loading';
        setState('ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status', 'loading');
        const params = {
            projectExecutionOverviewProjectId: this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryProjectExecutionOverviewViewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryProjectExecutionOverviewViewData = data;
            setState('ui.projectExecutionOverviewView.data.qryProjectExecutionOverviewView', data);
            this.qryProjectExecutionOverviewViewState = 'success';
            setState('ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status', 'success');
        }
        else {
            this.qryProjectExecutionOverviewViewState = 'error';
            setState('ui.projectExecutionOverviewView.action.qryProjectExecutionOverviewView.status', 'error');
            if (response.error) {
                console.error('qryProjectExecutionOverviewView failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryProjectExecutionOverviewView — bind UI events here */
    handleQryProjectExecutionOverviewViewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryProjectExecutionOverviewView();
    }
    /** setter for state ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId */
    setQryProjectExecutionOverviewViewProjectExecutionOverviewProjectId(value) {
        this.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId = value;
        setState('ui.projectExecutionOverviewView.input.qryProjectExecutionOverviewView.projectExecutionOverviewProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId — bind UI events here */
    handleQryProjectExecutionOverviewViewProjectExecutionOverviewProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryProjectExecutionOverviewViewProjectExecutionOverviewProjectId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmProjectExecutionOverviewViewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectExecutionOverviewViewBase.prototype, "qryProjectExecutionOverviewViewState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectExecutionOverviewViewBase.prototype, "qryProjectExecutionOverviewViewProjectExecutionOverviewProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectExecutionOverviewViewBase.prototype, "qryProjectExecutionOverviewViewData", void 0);
