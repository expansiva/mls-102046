/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/projectTimelineView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryProjectTimelineViewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/projectTimelineView.js';
/// **collab_i18n_start**
const message_pt = {
    'section.projectTimelineView.overview.title': 'Visão geral do cronograma',
    'organism.projectTimelineView.qryProjectTimelineView.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.empty': 'Nenhum registro encontrado',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.projectId.label': 'Project Id',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.workTasks.label': 'Work Tasks',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.scheduleEntries.label': 'Schedule Entries',
};
const message_pt_br = {
    'section.projectTimelineView.overview.title': 'Visão geral do cronograma',
    'organism.projectTimelineView.qryProjectTimelineView.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.empty': 'Nenhum registro encontrado',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.projectId.label': 'Project Id',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.workTasks.label': 'Work Tasks',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.scheduleEntries.label': 'Schedule Entries',
};
const message_en = {
    'section.projectTimelineView.overview.title': 'Visão geral do cronograma',
    'organism.projectTimelineView.qryProjectTimelineView.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.empty': 'Nenhum registro encontrado',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.projectId.label': 'Project Id',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.workTasks.label': 'Work Tasks',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.scheduleEntries.label': 'Schedule Entries',
};
const message_es = {
    'section.projectTimelineView.overview.title': 'Visão geral do cronograma',
    'organism.projectTimelineView.qryProjectTimelineView.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.title': 'Consultar o cronograma da obra',
    'intent.projectTimelineView.qryProjectTimelineView.list.empty': 'Nenhum registro encontrado',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.projectId.label': 'Project Id',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.workTasks.label': 'Work Tasks',
    'intent.projectTimelineView.qryProjectTimelineView.list.column.scheduleEntries.label': 'Schedule Entries',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.projectTimelineView.status',
    'ui.projectTimelineView.action.qryProjectTimelineView.status',
    'ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId',
    'ui.projectTimelineView.data.qryProjectTimelineView',
];
export class BuildFlowFsmProjectTimelineViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryProjectTimelineViewState — actionStatus, values: idle|loading|success|error */
        this.qryProjectTimelineViewState = 'idle';
        /** state qryProjectTimelineViewProjectTimelineProjectId — input */
        this.qryProjectTimelineViewProjectTimelineProjectId = '';
        /** state qryProjectTimelineViewData — queryResult, outputShape: object */
        this.qryProjectTimelineViewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.projectTimelineView.status', '');
        this.initStateValue('ui.projectTimelineView.action.qryProjectTimelineView.status', 'idle');
        this.initStateValue('ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId', '');
        this.initStateValue('ui.projectTimelineView.data.qryProjectTimelineView', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.projectTimelineView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectTimelineView.action.qryProjectTimelineView.status':
                this.qryProjectTimelineViewState = value ?? 'idle';
                break;
            case 'ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId':
                this.qryProjectTimelineViewProjectTimelineProjectId = value ?? '';
                break;
            case 'ui.projectTimelineView.data.qryProjectTimelineView':
                this.qryProjectTimelineViewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.projectTimelineView.status':
                this.status = value ?? '';
                break;
            case 'ui.projectTimelineView.action.qryProjectTimelineView.status':
                this.qryProjectTimelineViewState = value ?? 'idle';
                break;
            case 'ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId':
                this.qryProjectTimelineViewProjectTimelineProjectId = value ?? '';
                break;
            case 'ui.projectTimelineView.data.qryProjectTimelineView':
                this.qryProjectTimelineViewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryProjectTimelineView (query) — route buildFlowFsm.projectTimelineView.qryProjectTimelineView; inputs: projectTimelineProjectId; writes ui.projectTimelineView.data.qryProjectTimelineView; status ui.projectTimelineView.action.qryProjectTimelineView.status */
    async loadQryProjectTimelineView() {
        if (!this.qryProjectTimelineViewProjectTimelineProjectId) {
            this.qryProjectTimelineViewState = 'idle';
            setState('ui.projectTimelineView.action.qryProjectTimelineView.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryProjectTimelineViewState = 'loading';
        setState('ui.projectTimelineView.action.qryProjectTimelineView.status', 'loading');
        const params = {
            projectTimelineProjectId: this.qryProjectTimelineViewProjectTimelineProjectId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryProjectTimelineViewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryProjectTimelineViewData = data;
            setState('ui.projectTimelineView.data.qryProjectTimelineView', data);
            this.qryProjectTimelineViewState = 'success';
            setState('ui.projectTimelineView.action.qryProjectTimelineView.status', 'success');
        }
        else {
            this.qryProjectTimelineViewState = 'error';
            setState('ui.projectTimelineView.action.qryProjectTimelineView.status', 'error');
            if (response.error) {
                console.error('qryProjectTimelineView failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryProjectTimelineView — bind UI events here */
    handleQryProjectTimelineViewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryProjectTimelineView();
    }
    /** setter for state ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId */
    setQryProjectTimelineViewProjectTimelineProjectId(value) {
        this.qryProjectTimelineViewProjectTimelineProjectId = value;
        setState('ui.projectTimelineView.input.qryProjectTimelineView.projectTimelineProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryProjectTimelineViewProjectTimelineProjectId — bind UI events here */
    handleQryProjectTimelineViewProjectTimelineProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryProjectTimelineViewProjectTimelineProjectId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmProjectTimelineViewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectTimelineViewBase.prototype, "qryProjectTimelineViewState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectTimelineViewBase.prototype, "qryProjectTimelineViewProjectTimelineProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectTimelineViewBase.prototype, "qryProjectTimelineViewData", void 0);
