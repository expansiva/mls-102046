/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/scheduleRiskAssessmentView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryScheduleRiskAssessmentViewRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/scheduleRiskAssessmentView.js';
/// **collab_i18n_start**
const message_pt = {
    'section.scheduleRiskAssessmentView.overview.title': 'Tarefas em risco',
    'organism.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.empty': 'Nenhum registro encontrado',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.projectId.label': 'Project Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.workTaskId.label': 'Work Task Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.taskStatus.label': 'Task Status',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.dueDate.label': 'Due Date',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.progressPercent.label': 'Progress Percent',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskIndicators.label': 'Risk Indicators',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskExplanation.label': 'Risk Explanation',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.assessedAt.label': 'Assessed At',
};
const message_pt_br = {
    'section.scheduleRiskAssessmentView.overview.title': 'Tarefas em risco',
    'organism.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.empty': 'Nenhum registro encontrado',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.projectId.label': 'Project Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.workTaskId.label': 'Work Task Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.taskStatus.label': 'Task Status',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.dueDate.label': 'Due Date',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.progressPercent.label': 'Progress Percent',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskIndicators.label': 'Risk Indicators',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskExplanation.label': 'Risk Explanation',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.assessedAt.label': 'Assessed At',
};
const message_en = {
    'section.scheduleRiskAssessmentView.overview.title': 'Tarefas em risco',
    'organism.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.empty': 'Nenhum registro encontrado',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.projectId.label': 'Project Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.workTaskId.label': 'Work Task Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.taskStatus.label': 'Task Status',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.dueDate.label': 'Due Date',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.progressPercent.label': 'Progress Percent',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskIndicators.label': 'Risk Indicators',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskExplanation.label': 'Risk Explanation',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.assessedAt.label': 'Assessed At',
};
const message_es = {
    'section.scheduleRiskAssessmentView.overview.title': 'Tarefas em risco',
    'organism.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.title': 'Consultar tarefas em risco de atraso',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.empty': 'Nenhum registro encontrado',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.projectId.label': 'Project Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.workTaskId.label': 'Work Task Id',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.taskStatus.label': 'Task Status',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.dueDate.label': 'Due Date',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.progressPercent.label': 'Progress Percent',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskIndicators.label': 'Risk Indicators',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.riskExplanation.label': 'Risk Explanation',
    'intent.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView.list.column.assessedAt.label': 'Assessed At',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.scheduleRiskAssessmentView.status',
    'ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status',
    'ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId',
    'ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView',
];
export class BuildFlowFsmScheduleRiskAssessmentViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryScheduleRiskAssessmentViewState — actionStatus, values: idle|loading|success|error */
        this.qryScheduleRiskAssessmentViewState = 'idle';
        /** state qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId — input */
        this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId = '';
        /** state qryScheduleRiskAssessmentViewData — queryResult, outputShape: object */
        this.qryScheduleRiskAssessmentViewData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.scheduleRiskAssessmentView.status', '');
        this.initStateValue('ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status', 'idle');
        this.initStateValue('ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId', '');
        this.initStateValue('ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView', null);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.scheduleRiskAssessmentView.status':
                this.status = value ?? '';
                break;
            case 'ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status':
                this.qryScheduleRiskAssessmentViewState = value ?? 'idle';
                break;
            case 'ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId':
                this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId = value ?? '';
                break;
            case 'ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView':
                this.qryScheduleRiskAssessmentViewData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.scheduleRiskAssessmentView.status':
                this.status = value ?? '';
                break;
            case 'ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status':
                this.qryScheduleRiskAssessmentViewState = value ?? 'idle';
                break;
            case 'ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId':
                this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId = value ?? '';
                break;
            case 'ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView':
                this.qryScheduleRiskAssessmentViewData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action qryScheduleRiskAssessmentView (query) — route buildFlowFsm.scheduleRiskAssessmentView.qryScheduleRiskAssessmentView; inputs: scheduleRiskAssessmentProjectId; writes ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView; status ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status */
    async loadQryScheduleRiskAssessmentView() {
        if (!this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId) {
            this.qryScheduleRiskAssessmentViewState = 'idle';
            setState('ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryScheduleRiskAssessmentViewState = 'loading';
        setState('ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status', 'loading');
        const params = {
            scheduleRiskAssessmentProjectId: this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryScheduleRiskAssessmentViewRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryScheduleRiskAssessmentViewData = data;
            setState('ui.scheduleRiskAssessmentView.data.qryScheduleRiskAssessmentView', data);
            this.qryScheduleRiskAssessmentViewState = 'success';
            setState('ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status', 'success');
        }
        else {
            this.qryScheduleRiskAssessmentViewState = 'error';
            setState('ui.scheduleRiskAssessmentView.action.qryScheduleRiskAssessmentView.status', 'error');
            if (response.error) {
                console.error('qryScheduleRiskAssessmentView failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryScheduleRiskAssessmentView — bind UI events here */
    handleQryScheduleRiskAssessmentViewClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryScheduleRiskAssessmentView();
    }
    /** setter for state ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId */
    setQryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId(value) {
        this.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId = value;
        setState('ui.scheduleRiskAssessmentView.input.qryScheduleRiskAssessmentView.scheduleRiskAssessmentProjectId', value);
        this.requestUpdate();
    }
    /** handler for action set.qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId — bind UI events here */
    handleQryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmScheduleRiskAssessmentViewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmScheduleRiskAssessmentViewBase.prototype, "qryScheduleRiskAssessmentViewState", void 0);
__decorate([
    property()
], BuildFlowFsmScheduleRiskAssessmentViewBase.prototype, "qryScheduleRiskAssessmentViewScheduleRiskAssessmentProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmScheduleRiskAssessmentViewBase.prototype, "qryScheduleRiskAssessmentViewData", void 0);
