/// <mls fileReference="_102046_/l2/buildFlowFsm/web/shared/timeLogCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListTimeLogRoute, cmdCreateTimeLogRoute, cmdUpdateTimeLogRoute, cmdDeleteTimeLogRoute, qryWorkTaskPickerRoute, } from '/_102046_/l2/buildFlowFsm/web/contracts/timeLogCatalogue.js';
/// **collab_i18n_start**
const message_pt = {
    'section.timeLogCatalogue.recordList.title': 'Localizar registros de horas',
    'organism.timeLogCatalogue.qryListTimeLog.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.timeLogId.label': 'Time Log Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdDeleteTimeLog.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.action.cmdDeleteTimeLog': 'Excluir Registro de horas',
    'section.timeLogCatalogue.recordForm.title': 'Registrar ou corrigir horas',
    'organism.timeLogCatalogue.qryWorkTaskPicker.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.projectId.label': 'Project Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.description.label': 'Description',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.dueDate.label': 'Due Date',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.progressUpdate.label': 'Progress Update',
    'organism.timeLogCatalogue.cmdCreateTimeLog.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.action.cmdCreateTimeLog': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdUpdateTimeLog.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.action.cmdUpdateTimeLog': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.status.label': 'Status',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'action.cmdCreateTimeLog.success': 'Registrar as horas trabalhadas: OK',
    'action.cmdCreateTimeLog.error': 'Registrar as horas trabalhadas: falhou',
    'action.cmdUpdateTimeLog.success': 'Atualizar Registro de horas: OK',
    'action.cmdUpdateTimeLog.error': 'Atualizar Registro de horas: falhou',
    'action.cmdDeleteTimeLog.success': 'Excluir Registro de horas: OK',
    'action.cmdDeleteTimeLog.error': 'Excluir Registro de horas: falhou',
    'section.timeLogCatalogue.recordWorkspace.title': 'Registros e edição',
};
const message_pt_br = {
    'section.timeLogCatalogue.recordList.title': 'Localizar registros de horas',
    'organism.timeLogCatalogue.qryListTimeLog.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.timeLogId.label': 'Time Log Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdDeleteTimeLog.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.action.cmdDeleteTimeLog': 'Excluir Registro de horas',
    'section.timeLogCatalogue.recordForm.title': 'Registrar ou corrigir horas',
    'organism.timeLogCatalogue.qryWorkTaskPicker.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.projectId.label': 'Project Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.description.label': 'Description',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.dueDate.label': 'Due Date',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.progressUpdate.label': 'Progress Update',
    'organism.timeLogCatalogue.cmdCreateTimeLog.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.action.cmdCreateTimeLog': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdUpdateTimeLog.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.action.cmdUpdateTimeLog': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.status.label': 'Status',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'action.cmdCreateTimeLog.success': 'Registrar as horas trabalhadas: OK',
    'action.cmdCreateTimeLog.error': 'Registrar as horas trabalhadas: falhou',
    'action.cmdUpdateTimeLog.success': 'Atualizar Registro de horas: OK',
    'action.cmdUpdateTimeLog.error': 'Atualizar Registro de horas: falhou',
    'action.cmdDeleteTimeLog.success': 'Excluir Registro de horas: OK',
    'action.cmdDeleteTimeLog.error': 'Excluir Registro de horas: falhou',
    'section.timeLogCatalogue.recordWorkspace.title': 'Registros e edição',
};
const message_en = {
    'section.timeLogCatalogue.recordList.title': 'Localizar registros de horas',
    'organism.timeLogCatalogue.qryListTimeLog.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.timeLogId.label': 'Time Log Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdDeleteTimeLog.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.action.cmdDeleteTimeLog': 'Excluir Registro de horas',
    'section.timeLogCatalogue.recordForm.title': 'Registrar ou corrigir horas',
    'organism.timeLogCatalogue.qryWorkTaskPicker.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.projectId.label': 'Project Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.description.label': 'Description',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.dueDate.label': 'Due Date',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.progressUpdate.label': 'Progress Update',
    'organism.timeLogCatalogue.cmdCreateTimeLog.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.action.cmdCreateTimeLog': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdUpdateTimeLog.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.action.cmdUpdateTimeLog': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.status.label': 'Status',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'action.cmdCreateTimeLog.success': 'Registrar as horas trabalhadas: OK',
    'action.cmdCreateTimeLog.error': 'Registrar as horas trabalhadas: falhou',
    'action.cmdUpdateTimeLog.success': 'Atualizar Registro de horas: OK',
    'action.cmdUpdateTimeLog.error': 'Atualizar Registro de horas: falhou',
    'action.cmdDeleteTimeLog.success': 'Excluir Registro de horas: OK',
    'action.cmdDeleteTimeLog.error': 'Excluir Registro de horas: falhou',
    'section.timeLogCatalogue.recordWorkspace.title': 'Registros e edição',
};
const message_es = {
    'section.timeLogCatalogue.recordList.title': 'Localizar registros de horas',
    'organism.timeLogCatalogue.qryListTimeLog.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.title': 'Listar Registro de horas',
    'intent.timeLogCatalogue.qryListTimeLog.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.timeLogId.label': 'Time Log Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.qryListTimeLog.list.column.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdDeleteTimeLog.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.title': 'Excluir Registro de horas',
    'intent.timeLogCatalogue.cmdDeleteTimeLog.form.action.cmdDeleteTimeLog': 'Excluir Registro de horas',
    'section.timeLogCatalogue.recordForm.title': 'Registrar ou corrigir horas',
    'organism.timeLogCatalogue.qryWorkTaskPicker.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.title': 'Listar Tarefa de trabalho',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.empty': 'Nenhum registro encontrado',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.workTaskId.label': 'Work Task Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.projectId.label': 'Project Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.assignedFieldWorkerId.label': 'Assigned Field Worker Id',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.description.label': 'Description',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.dueDate.label': 'Due Date',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.status.label': 'Status',
    'intent.timeLogCatalogue.qryWorkTaskPicker.list.column.progressUpdate.label': 'Progress Update',
    'organism.timeLogCatalogue.cmdCreateTimeLog.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.title': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.action.cmdCreateTimeLog': 'Registrar as horas trabalhadas',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdCreateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'organism.timeLogCatalogue.cmdUpdateTimeLog.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.title': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.action.cmdUpdateTimeLog': 'Atualizar Registro de horas',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.status.label': 'Status',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.fieldWorkerId.label': 'Field Worker Id',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.workDate.label': 'Work Date',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.timeLogCatalogue.cmdUpdateTimeLog.form.field.hourlyLaborCost.label': 'Hourly Labor Cost',
    'action.cmdCreateTimeLog.success': 'Registrar as horas trabalhadas: OK',
    'action.cmdCreateTimeLog.error': 'Registrar as horas trabalhadas: falhou',
    'action.cmdUpdateTimeLog.success': 'Atualizar Registro de horas: OK',
    'action.cmdUpdateTimeLog.error': 'Atualizar Registro de horas: falhou',
    'action.cmdDeleteTimeLog.success': 'Excluir Registro de horas: OK',
    'action.cmdDeleteTimeLog.error': 'Excluir Registro de horas: falhou',
    'section.timeLogCatalogue.recordWorkspace.title': 'Registros e edição',
};
export const messages = { 'pt': message_pt, 'pt-br': message_pt_br, 'en': message_en, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.timeLogCatalogue.status',
    'ui.timeLogCatalogue.action.qryListTimeLog.status',
    'ui.timeLogCatalogue.data.qryListTimeLog',
    'ui.timeLogCatalogue.action.cmdCreateTimeLog.status',
    'ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId',
    'ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate',
    'ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked',
    'ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost',
    'ui.timeLogCatalogue.output.cmdCreateTimeLog',
    'ui.timeLogCatalogue.action.cmdCreateTimeLog.error',
    'ui.timeLogCatalogue.action.cmdUpdateTimeLog.status',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.status',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked',
    'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost',
    'ui.timeLogCatalogue.output.cmdUpdateTimeLog',
    'ui.timeLogCatalogue.action.cmdUpdateTimeLog.error',
    'ui.timeLogCatalogue.action.cmdDeleteTimeLog.status',
    'ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId',
    'ui.timeLogCatalogue.output.cmdDeleteTimeLog',
    'ui.timeLogCatalogue.action.cmdDeleteTimeLog.error',
    'ui.timeLogCatalogue.action.qryWorkTaskPicker.status',
    'ui.timeLogCatalogue.data.qryWorkTaskPicker',
];
export class BuildFlowFsmTimeLogCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state qryListTimeLogState — actionStatus, values: idle|loading|success|error */
        this.qryListTimeLogState = 'idle';
        /** state qryListTimeLogData — queryResult, outputShape: array */
        this.qryListTimeLogData = [];
        /** state cmdCreateTimeLogState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateTimeLogState = 'idle';
        /** state cmdCreateTimeLogWorkTaskWorkTaskId — input */
        this.cmdCreateTimeLogWorkTaskWorkTaskId = '';
        /** state cmdCreateTimeLogWorkDate — input */
        this.cmdCreateTimeLogWorkDate = '';
        /** state cmdCreateTimeLogHoursWorked — input */
        this.cmdCreateTimeLogHoursWorked = '';
        /** state cmdCreateTimeLogHourlyLaborCost — input */
        this.cmdCreateTimeLogHourlyLaborCost = '';
        /** state cmdCreateTimeLogOutput — commandOutput */
        this.cmdCreateTimeLogOutput = null;
        /** state cmdCreateTimeLogError — actionError */
        this.cmdCreateTimeLogError = '';
        /** state cmdUpdateTimeLogState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateTimeLogState = 'idle';
        /** state cmdUpdateTimeLogTimeLogId — input */
        this.cmdUpdateTimeLogTimeLogId = '';
        /** state cmdUpdateTimeLogStatus — input */
        this.cmdUpdateTimeLogStatus = '';
        /** state cmdUpdateTimeLogWorkTaskId — input */
        this.cmdUpdateTimeLogWorkTaskId = '';
        /** state cmdUpdateTimeLogFieldWorkerId — input */
        this.cmdUpdateTimeLogFieldWorkerId = '';
        /** state cmdUpdateTimeLogWorkDate — input */
        this.cmdUpdateTimeLogWorkDate = '';
        /** state cmdUpdateTimeLogHoursWorked — input */
        this.cmdUpdateTimeLogHoursWorked = '';
        /** state cmdUpdateTimeLogHourlyLaborCost — input */
        this.cmdUpdateTimeLogHourlyLaborCost = '';
        /** state cmdUpdateTimeLogOutput — commandOutput */
        this.cmdUpdateTimeLogOutput = null;
        /** state cmdUpdateTimeLogError — actionError */
        this.cmdUpdateTimeLogError = '';
        /** state cmdDeleteTimeLogState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteTimeLogState = 'idle';
        /** state cmdDeleteTimeLogTimeLogId — input */
        this.cmdDeleteTimeLogTimeLogId = '';
        /** state cmdDeleteTimeLogOutput — commandOutput */
        this.cmdDeleteTimeLogOutput = null;
        /** state cmdDeleteTimeLogError — actionError */
        this.cmdDeleteTimeLogError = '';
        /** state qryWorkTaskPickerState — actionStatus, values: idle|loading|success|error */
        this.qryWorkTaskPickerState = 'idle';
        /** state qryWorkTaskPickerData — queryResult, outputShape: array */
        this.qryWorkTaskPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.timeLogCatalogue.status', '');
        this.initStateValue('ui.timeLogCatalogue.action.qryListTimeLog.status', 'idle');
        this.initStateValue('ui.timeLogCatalogue.data.qryListTimeLog', []);
        this.initStateValue('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'idle');
        this.initStateValue('ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost', '');
        this.initStateValue('ui.timeLogCatalogue.output.cmdCreateTimeLog', null);
        this.initStateValue('ui.timeLogCatalogue.action.cmdCreateTimeLog.error', '');
        this.initStateValue('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'idle');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.status', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked', '');
        this.initStateValue('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost', '');
        this.initStateValue('ui.timeLogCatalogue.output.cmdUpdateTimeLog', null);
        this.initStateValue('ui.timeLogCatalogue.action.cmdUpdateTimeLog.error', '');
        this.initStateValue('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'idle');
        this.initStateValue('ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId', '');
        this.initStateValue('ui.timeLogCatalogue.output.cmdDeleteTimeLog', null);
        this.initStateValue('ui.timeLogCatalogue.action.cmdDeleteTimeLog.error', '');
        this.initStateValue('ui.timeLogCatalogue.action.qryWorkTaskPicker.status', 'idle');
        this.initStateValue('ui.timeLogCatalogue.data.qryWorkTaskPicker', []);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListTimeLog();
        void this.loadQryWorkTaskPicker();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.timeLogCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.qryListTimeLog.status':
                this.qryListTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.data.qryListTimeLog':
                this.qryListTimeLogData = value ?? [];
                break;
            case 'ui.timeLogCatalogue.action.cmdCreateTimeLog.status':
                this.cmdCreateTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId':
                this.cmdCreateTimeLogWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate':
                this.cmdCreateTimeLogWorkDate = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked':
                this.cmdCreateTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost':
                this.cmdCreateTimeLogHourlyLaborCost = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdCreateTimeLog':
                this.cmdCreateTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdCreateTimeLog.error':
                this.cmdCreateTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.cmdUpdateTimeLog.status':
                this.cmdUpdateTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId':
                this.cmdUpdateTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.status':
                this.cmdUpdateTimeLogStatus = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId':
                this.cmdUpdateTimeLogWorkTaskId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId':
                this.cmdUpdateTimeLogFieldWorkerId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate':
                this.cmdUpdateTimeLogWorkDate = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked':
                this.cmdUpdateTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost':
                this.cmdUpdateTimeLogHourlyLaborCost = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdUpdateTimeLog':
                this.cmdUpdateTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdUpdateTimeLog.error':
                this.cmdUpdateTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.cmdDeleteTimeLog.status':
                this.cmdDeleteTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId':
                this.cmdDeleteTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdDeleteTimeLog':
                this.cmdDeleteTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdDeleteTimeLog.error':
                this.cmdDeleteTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.qryWorkTaskPicker.status':
                this.qryWorkTaskPickerState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.data.qryWorkTaskPicker':
                this.qryWorkTaskPickerData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.timeLogCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.qryListTimeLog.status':
                this.qryListTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.data.qryListTimeLog':
                this.qryListTimeLogData = value ?? [];
                break;
            case 'ui.timeLogCatalogue.action.cmdCreateTimeLog.status':
                this.cmdCreateTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId':
                this.cmdCreateTimeLogWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate':
                this.cmdCreateTimeLogWorkDate = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked':
                this.cmdCreateTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost':
                this.cmdCreateTimeLogHourlyLaborCost = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdCreateTimeLog':
                this.cmdCreateTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdCreateTimeLog.error':
                this.cmdCreateTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.cmdUpdateTimeLog.status':
                this.cmdUpdateTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId':
                this.cmdUpdateTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.status':
                this.cmdUpdateTimeLogStatus = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId':
                this.cmdUpdateTimeLogWorkTaskId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId':
                this.cmdUpdateTimeLogFieldWorkerId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate':
                this.cmdUpdateTimeLogWorkDate = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked':
                this.cmdUpdateTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost':
                this.cmdUpdateTimeLogHourlyLaborCost = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdUpdateTimeLog':
                this.cmdUpdateTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdUpdateTimeLog.error':
                this.cmdUpdateTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.cmdDeleteTimeLog.status':
                this.cmdDeleteTimeLogState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId':
                this.cmdDeleteTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.timeLogCatalogue.output.cmdDeleteTimeLog':
                this.cmdDeleteTimeLogOutput = value ?? null;
                break;
            case 'ui.timeLogCatalogue.action.cmdDeleteTimeLog.error':
                this.cmdDeleteTimeLogError = value ?? '';
                break;
            case 'ui.timeLogCatalogue.action.qryWorkTaskPicker.status':
                this.qryWorkTaskPickerState = value ?? 'idle';
                break;
            case 'ui.timeLogCatalogue.data.qryWorkTaskPicker':
                this.qryWorkTaskPickerData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListTimeLog (query) — route buildFlowFsm.timeLogCatalogue.qryListTimeLog; inputs: (none); writes ui.timeLogCatalogue.data.qryListTimeLog; status ui.timeLogCatalogue.action.qryListTimeLog.status */
    async loadQryListTimeLog() {
        this.qryListTimeLogState = 'loading';
        setState('ui.timeLogCatalogue.action.qryListTimeLog.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListTimeLogRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListTimeLogData = data;
            setState('ui.timeLogCatalogue.data.qryListTimeLog', data);
            this.qryListTimeLogState = 'success';
            setState('ui.timeLogCatalogue.action.qryListTimeLog.status', 'success');
        }
        else {
            this.qryListTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.qryListTimeLog.status', 'error');
            if (response.error) {
                console.error('qryListTimeLog failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListTimeLog — bind UI events here */
    handleQryListTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListTimeLog();
    }
    /** action cmdCreateTimeLog (command) — route buildFlowFsm.timeLogCatalogue.cmdCreateTimeLog; inputs: workTaskWorkTaskId, workDate, hoursWorked, hourlyLaborCost; writes ui.timeLogCatalogue.output.cmdCreateTimeLog; status ui.timeLogCatalogue.action.cmdCreateTimeLog.status; feedback keys action.cmdCreateTimeLog.success / action.cmdCreateTimeLog.error */
    async cmdCreateTimeLog() {
        if (!this.cmdCreateTimeLogWorkTaskWorkTaskId) {
            this.cmdCreateTimeLogState = 'idle';
            setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdCreateTimeLogState = 'loading';
        setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'loading');
        this.cmdCreateTimeLogError = '';
        setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.error', '');
        const hoursWorkedNum = Number(this.cmdCreateTimeLogHoursWorked);
        const hourlyLaborCostNum = Number(this.cmdCreateTimeLogHourlyLaborCost);
        const params = {
            workTaskWorkTaskId: this.cmdCreateTimeLogWorkTaskWorkTaskId,
            workDate: this.cmdCreateTimeLogWorkDate,
            hoursWorked: Number.isNaN(hoursWorkedNum) ? 0 : hoursWorkedNum,
            hourlyLaborCost: Number.isNaN(hourlyLaborCostNum) ? 0 : hourlyLaborCostNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateTimeLogRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateTimeLog.error');
            this.cmdCreateTimeLogError = errMsg;
            setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.error', errMsg);
            this.cmdCreateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateTimeLogOutput = data;
        setState('ui.timeLogCatalogue.output.cmdCreateTimeLog', data);
        try {
            await this.loadQryListTimeLog();
            if (this.qryListTimeLogState === 'error') {
                this.cmdCreateTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateTimeLog refresh failed', refreshError);
            this.cmdCreateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryWorkTaskPicker();
            if (this.qryWorkTaskPickerState === 'error') {
                this.cmdCreateTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateTimeLog refresh failed', refreshError);
            this.cmdCreateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateTimeLogWorkTaskWorkTaskId = '';
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId', '');
        this.cmdCreateTimeLogWorkDate = '';
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate', '');
        this.cmdCreateTimeLogHoursWorked = '';
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked', '');
        this.cmdCreateTimeLogHourlyLaborCost = '';
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost', '');
        this.cmdCreateTimeLogState = 'success';
        setState('ui.timeLogCatalogue.action.cmdCreateTimeLog.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateTimeLog — bind UI events here */
    handleCmdCreateTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateTimeLog();
        });
    }
    /** action cmdUpdateTimeLog (command) — route buildFlowFsm.timeLogCatalogue.cmdUpdateTimeLog; inputs: timeLogId, status, workTaskId, fieldWorkerId, workDate, hoursWorked, hourlyLaborCost; writes ui.timeLogCatalogue.output.cmdUpdateTimeLog; status ui.timeLogCatalogue.action.cmdUpdateTimeLog.status; feedback keys action.cmdUpdateTimeLog.success / action.cmdUpdateTimeLog.error */
    async cmdUpdateTimeLog() {
        if (!this.cmdUpdateTimeLogTimeLogId) {
            this.cmdUpdateTimeLogState = 'idle';
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.cmdUpdateTimeLogWorkTaskId) {
            this.cmdUpdateTimeLogState = 'idle';
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateTimeLogState = 'loading';
        setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'loading');
        this.cmdUpdateTimeLogError = '';
        setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.error', '');
        const hoursWorkedNum = Number(this.cmdUpdateTimeLogHoursWorked);
        const hourlyLaborCostNum = Number(this.cmdUpdateTimeLogHourlyLaborCost);
        const params = {
            timeLogId: this.cmdUpdateTimeLogTimeLogId,
            status: this.cmdUpdateTimeLogStatus,
            workTaskId: this.cmdUpdateTimeLogWorkTaskId,
            fieldWorkerId: this.cmdUpdateTimeLogFieldWorkerId,
            workDate: this.cmdUpdateTimeLogWorkDate,
            hoursWorked: Number.isNaN(hoursWorkedNum) ? 0 : hoursWorkedNum,
            hourlyLaborCost: Number.isNaN(hourlyLaborCostNum) ? 0 : hourlyLaborCostNum,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateTimeLogRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateTimeLog.error');
            this.cmdUpdateTimeLogError = errMsg;
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.error', errMsg);
            this.cmdUpdateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateTimeLogOutput = data;
        setState('ui.timeLogCatalogue.output.cmdUpdateTimeLog', data);
        try {
            await this.loadQryListTimeLog();
            if (this.qryListTimeLogState === 'error') {
                this.cmdUpdateTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateTimeLog refresh failed', refreshError);
            this.cmdUpdateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryWorkTaskPicker();
            if (this.qryWorkTaskPickerState === 'error') {
                this.cmdUpdateTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateTimeLog refresh failed', refreshError);
            this.cmdUpdateTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateTimeLogTimeLogId = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId', '');
        this.cmdUpdateTimeLogStatus = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.status', '');
        this.cmdUpdateTimeLogWorkTaskId = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId', '');
        this.cmdUpdateTimeLogFieldWorkerId = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId', '');
        this.cmdUpdateTimeLogWorkDate = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate', '');
        this.cmdUpdateTimeLogHoursWorked = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked', '');
        this.cmdUpdateTimeLogHourlyLaborCost = '';
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost', '');
        this.cmdUpdateTimeLogState = 'success';
        setState('ui.timeLogCatalogue.action.cmdUpdateTimeLog.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateTimeLog — bind UI events here */
    handleCmdUpdateTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateTimeLog();
        });
    }
    /** action cmdDeleteTimeLog (command) — route buildFlowFsm.timeLogCatalogue.cmdDeleteTimeLog; inputs: timeLogId; writes ui.timeLogCatalogue.output.cmdDeleteTimeLog; status ui.timeLogCatalogue.action.cmdDeleteTimeLog.status; feedback keys action.cmdDeleteTimeLog.success / action.cmdDeleteTimeLog.error */
    async cmdDeleteTimeLog() {
        if (!this.cmdDeleteTimeLogTimeLogId) {
            this.cmdDeleteTimeLogState = 'idle';
            setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteTimeLogState = 'loading';
        setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'loading');
        this.cmdDeleteTimeLogError = '';
        setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.error', '');
        const params = {
            timeLogId: this.cmdDeleteTimeLogTimeLogId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteTimeLogRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteTimeLog.error');
            this.cmdDeleteTimeLogError = errMsg;
            setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.error', errMsg);
            this.cmdDeleteTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteTimeLogOutput = data;
        setState('ui.timeLogCatalogue.output.cmdDeleteTimeLog', data);
        try {
            await this.loadQryListTimeLog();
            if (this.qryListTimeLogState === 'error') {
                this.cmdDeleteTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteTimeLog refresh failed', refreshError);
            this.cmdDeleteTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryWorkTaskPicker();
            if (this.qryWorkTaskPickerState === 'error') {
                this.cmdDeleteTimeLogState = 'error';
                setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteTimeLog refresh failed', refreshError);
            this.cmdDeleteTimeLogState = 'error';
            setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteTimeLogTimeLogId = '';
        setState('ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId', '');
        this.cmdDeleteTimeLogState = 'success';
        setState('ui.timeLogCatalogue.action.cmdDeleteTimeLog.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteTimeLog — bind UI events here */
    handleCmdDeleteTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteTimeLog();
        });
    }
    /** action qryWorkTaskPicker (query) — route buildFlowFsm.timeLogCatalogue.qryWorkTaskPicker; inputs: (none); writes ui.timeLogCatalogue.data.qryWorkTaskPicker; status ui.timeLogCatalogue.action.qryWorkTaskPicker.status */
    async loadQryWorkTaskPicker() {
        this.qryWorkTaskPickerState = 'loading';
        setState('ui.timeLogCatalogue.action.qryWorkTaskPicker.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryWorkTaskPickerRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryWorkTaskPickerData = data;
            setState('ui.timeLogCatalogue.data.qryWorkTaskPicker', data);
            this.qryWorkTaskPickerState = 'success';
            setState('ui.timeLogCatalogue.action.qryWorkTaskPicker.status', 'success');
        }
        else {
            this.qryWorkTaskPickerState = 'error';
            setState('ui.timeLogCatalogue.action.qryWorkTaskPicker.status', 'error');
            if (response.error) {
                console.error('qryWorkTaskPicker failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryWorkTaskPicker — bind UI events here */
    handleQryWorkTaskPickerClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryWorkTaskPicker();
    }
    /** setter for state ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId */
    setCmdCreateTimeLogWorkTaskWorkTaskId(value) {
        this.cmdCreateTimeLogWorkTaskWorkTaskId = value;
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.workTaskWorkTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTimeLogWorkTaskWorkTaskId — bind UI events here */
    handleCmdCreateTimeLogWorkTaskWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTimeLogWorkTaskWorkTaskId(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate */
    setCmdCreateTimeLogWorkDate(value) {
        this.cmdCreateTimeLogWorkDate = value;
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.workDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTimeLogWorkDate — bind UI events here */
    handleCmdCreateTimeLogWorkDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTimeLogWorkDate(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked */
    setCmdCreateTimeLogHoursWorked(value) {
        this.cmdCreateTimeLogHoursWorked = value;
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.hoursWorked', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTimeLogHoursWorked — bind UI events here */
    handleCmdCreateTimeLogHoursWorkedChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTimeLogHoursWorked(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost */
    setCmdCreateTimeLogHourlyLaborCost(value) {
        this.cmdCreateTimeLogHourlyLaborCost = value;
        setState('ui.timeLogCatalogue.input.cmdCreateTimeLog.hourlyLaborCost', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTimeLogHourlyLaborCost — bind UI events here */
    handleCmdCreateTimeLogHourlyLaborCostChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTimeLogHourlyLaborCost(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId */
    setCmdUpdateTimeLogTimeLogId(value) {
        this.cmdUpdateTimeLogTimeLogId = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.timeLogId', value);
        const collection = getState('ui.timeLogCatalogue.data.qryListTimeLog') ?? this.qryListTimeLogData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.timeLogId) === String(value));
            if (item) {
                this.cmdUpdateTimeLogStatus = item.status;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.status', item.status);
                this.cmdUpdateTimeLogFieldWorkerId = item.fieldWorkerId;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId', item.fieldWorkerId);
                this.cmdUpdateTimeLogWorkDate = item.workDate;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate', item.workDate);
                this.cmdUpdateTimeLogHoursWorked = String(item.hoursWorked);
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked', String(item.hoursWorked));
                this.cmdUpdateTimeLogHourlyLaborCost = String(item.hourlyLaborCost);
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost', String(item.hourlyLaborCost));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogTimeLogId — bind UI events here */
    handleCmdUpdateTimeLogTimeLogIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogTimeLogId(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.status */
    setCmdUpdateTimeLogStatus(value) {
        this.cmdUpdateTimeLogStatus = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogStatus — bind UI events here */
    handleCmdUpdateTimeLogStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogStatus(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId */
    setCmdUpdateTimeLogWorkTaskId(value) {
        this.cmdUpdateTimeLogWorkTaskId = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workTaskId', value);
        const collection = getState('ui.timeLogCatalogue.data.qryListTimeLog') ?? this.qryListTimeLogData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.workTaskId) === String(value));
            if (item) {
                this.cmdUpdateTimeLogStatus = item.status;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.status', item.status);
                this.cmdUpdateTimeLogFieldWorkerId = item.fieldWorkerId;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId', item.fieldWorkerId);
                this.cmdUpdateTimeLogWorkDate = item.workDate;
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate', item.workDate);
                this.cmdUpdateTimeLogHoursWorked = String(item.hoursWorked);
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked', String(item.hoursWorked));
                this.cmdUpdateTimeLogHourlyLaborCost = String(item.hourlyLaborCost);
                setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost', String(item.hourlyLaborCost));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogWorkTaskId — bind UI events here */
    handleCmdUpdateTimeLogWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogWorkTaskId(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId */
    setCmdUpdateTimeLogFieldWorkerId(value) {
        this.cmdUpdateTimeLogFieldWorkerId = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.fieldWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogFieldWorkerId — bind UI events here */
    handleCmdUpdateTimeLogFieldWorkerIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogFieldWorkerId(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate */
    setCmdUpdateTimeLogWorkDate(value) {
        this.cmdUpdateTimeLogWorkDate = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.workDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogWorkDate — bind UI events here */
    handleCmdUpdateTimeLogWorkDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogWorkDate(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked */
    setCmdUpdateTimeLogHoursWorked(value) {
        this.cmdUpdateTimeLogHoursWorked = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hoursWorked', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogHoursWorked — bind UI events here */
    handleCmdUpdateTimeLogHoursWorkedChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogHoursWorked(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost */
    setCmdUpdateTimeLogHourlyLaborCost(value) {
        this.cmdUpdateTimeLogHourlyLaborCost = value;
        setState('ui.timeLogCatalogue.input.cmdUpdateTimeLog.hourlyLaborCost', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTimeLogHourlyLaborCost — bind UI events here */
    handleCmdUpdateTimeLogHourlyLaborCostChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTimeLogHourlyLaborCost(value);
    }
    /** setter for state ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId */
    setCmdDeleteTimeLogTimeLogId(value) {
        this.cmdDeleteTimeLogTimeLogId = value;
        setState('ui.timeLogCatalogue.input.cmdDeleteTimeLog.timeLogId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteTimeLogTimeLogId — bind UI events here */
    handleCmdDeleteTimeLogTimeLogIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteTimeLogTimeLogId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "qryListTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "qryListTimeLogData", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogWorkTaskWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogWorkDate", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogHoursWorked", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogHourlyLaborCost", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdCreateTimeLogError", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogTimeLogId", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogStatus", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogFieldWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogWorkDate", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogHoursWorked", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogHourlyLaborCost", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdUpdateTimeLogError", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdDeleteTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdDeleteTimeLogTimeLogId", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdDeleteTimeLogOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "cmdDeleteTimeLogError", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "qryWorkTaskPickerState", void 0);
__decorate([
    property()
], BuildFlowFsmTimeLogCatalogueBase.prototype, "qryWorkTaskPickerData", void 0);
